# Fold Print Agent

A small program for the counter computer. It pairs with your Fold POS account,
waits for print jobs the server has already rendered (claim tickets, garment
tags, heat-seal labels) and prints them on the USB or network printer next to
it. **It is what lets the browser version of Fold POS print** — a web page
can't talk to a receipt printer, so this does it on the page's behalf.

Works on **macOS**, **Windows 10/11** and Linux. No admin rights needed. No
printer driver settings are changed — it writes the raw ESC/POS / ZPL bytes to
the queue you already have.

## Install

### Windows: one-click installer

The easy way: in Fold POS on the counter computer, open **Settings → Receipts**
and click **Download for Windows**. That file is named
`Fold-Print-Setup-<code>.exe` and connects itself to your store; the code in
the name is good for an hour and only once. Double-click it. Nothing
else is needed — Node.js comes inside the installer, and no admin password is
asked for.

1. **Windows may say "Windows protected your PC".** Click **More info**, then
   **Run anyway**. That warning is SmartScreen saying the file is new, not that
   anything is wrong with it — the installer is not yet code-signed.
2. Click through the installer (Next → Install). It installs to
   `%LOCALAPPDATA%\Programs\Fold Print Agent`, connects to your store, starts the
   agent, and sets it to start again whenever you sign in.
3. That's it. Within a minute Fold POS sets up the receipt printer it finds on
   this computer and prints a test receipt. (It only does this when the store
   has no receipt printer yet and this computer has exactly one receipt
   printer; otherwise pick it in Settings → Receipts → Add printer.)

The generic `Fold-Print-Agent-Setup.exe` from foldpos.com/download (or an
expired code) still works the old way: leave **"Open the Fold print helper
page"** ticked on the last screen, and in Fold POS go to **Settings → Receipts →
Fold Print Agent → "Pair with a code"** and type the 6-digit code into the page
that opens (**http://localhost:9377**).

Reinstalling or upgrading a computer that is already connected keeps its
connection, whatever the file is called — unless the computer was removed in
Fold POS, in which case a fresh download from Fold POS connects it again.

Afterwards the status page is in the Start Menu under **Fold Print Agent →
Fold Print Agent status**, and the agent appears in Add/Remove Programs like
any other app.

> Uninstalling deliberately **keeps the pairing** (`%APPDATA%\FoldPrintAgent\
> config.json`), so reinstalling to fix a problem doesn't mean pairing again.
> To actually disconnect this computer, un-pair it first — the button on the
> status page, or `fold-print-agent unpair` — and revoke it in Fold POS →
> Settings → Receipts.

### macOS, Linux, or Windows from a terminal

You need Node.js 18 or newer (https://nodejs.org — "LTS", default options).

**macOS** (Terminal):

```sh
curl -fsSL https://raw.githubusercontent.com/jimilchoksi/fold-pos-api/main/print-agent/scripts/install-macos.sh | bash
```

**Windows** (PowerShell) — only if you'd rather not use the installer above,
e.g. you already manage Node.js yourself:

```powershell
irm https://raw.githubusercontent.com/jimilchoksi/fold-pos-api/main/print-agent/scripts/install-windows.ps1 | iex
```

Both scripts install the agent, start it at login, and open the status page.
(Until the repo is public, copy the `print-agent` folder to the computer and
run `npm install -g .` inside it instead.)

## Pair it

1. In Fold POS: **Settings → Receipts → Fold Print Agent → "Pair with a code"**.
   You get a 6-digit code valid for 10 minutes.
2. Open **http://localhost:9377** on the counter computer and type the code
   (or run `fold-print-agent pair 123456 --name "Front counter"`).

That's it. The POS now lists this computer under *Print agents* and shows the
printers it can see when you add a printer.

## Day to day

| | |
|---|---|
| Status page | http://localhost:9377 — connection, printers, last 20 jobs, errors |
| Test a printer | `fold-print-agent test Epson_TM_T20`, `… test 192.168.1.50:9100` or `… test usb:04b8:0202` |
| Ask a USB printer how it is | `fold-print-agent ask usb:04b8:0202` — answers "ready", "out of paper", "cover open" |
| See printers | `fold-print-agent printers` |
| Logs | macOS `~/Library/Application Support/FoldPrintAgent/agent.log` · Windows `%APPDATA%\FoldPrintAgent\agent.log` |
| Stop / start at login | `fold-print-agent uninstall-service` / `install-service` |
| Un-pair | `fold-print-agent unpair` (and revoke it in Fold POS) |

Network printers that the OS doesn't list (Ethernet Epson/Star/Bixolon/Zebra)
go in `config.json`:

```json
"manualPrinters": [{ "name": "Zebra tags", "address": "192.168.1.60:9100" }]
```

## How it prints

| Platform | USB / Bluetooth queue | Direct USB | LAN printer |
|---|---|---|---|
| macOS / Linux | CUPS `lp -o raw` | libusb bulk write (optional) | TCP 9100 |
| Windows | Spooler RAW datatype via `winspool.drv` (PowerShell P/Invoke, no native module) | libusb bulk write (optional, needs WinUSB) | TCP 9100 |

Failed jobs are acknowledged with the error; the server retries up to 3 times
and shows the reason in Fold POS. A job the agent claims but never finishes
(crash, power cut) is released after 2 minutes and reprinted.

## USB printers the computer "can't see"

Most Epson TM models (and some Star and Bixolon) present themselves to the
computer as a **vendor-class** device rather than a printer. macOS and Linux
only build a print queue for printer-class devices, so such a printer never
appears in System Settings or in `lpstat -p`, and nothing — not a cable, not a
driver — makes it appear. The symptom is "the printer isn't there".

The agent can talk to those printers itself, without a queue and without a
driver, by writing the ESC/POS bytes straight to the device.

**Turning it on.** It needs one native module, kept optional so the agent
still installs and runs everywhere without it:

```sh
cd print-agent
npm install usb          # node-usb v3+; ships prebuilt binaries for macOS,
                         # Windows and Linux, so no compiler is normally needed
fold-print-agent printers
```

We use node-usb's **WebUSB** API (`usb.getDevices()`, `device.transferOut()`),
which is what v3 exposes; the old libusb-shaped API from v2 is gone.

Without it everything else — CUPS queues, Windows queues, LAN printers — works
exactly as before, and the status page says USB support is off and why.

**Addresses** look like `usb:<vendor>:<product>[:<serial>]`, four lower-case
hex digits each:

```
usb:04b8:0202                          Epson TM-T88V
usb:04b8:0202:4D5844469192450000       …when two identical printers share a counter
```

Use one anywhere a printer address goes: `fold-print-agent test usb:04b8:0202`,
or as the address of an AGENT printer in Fold POS.

A printer the OS *does* have a queue for is listed once, as the queue — the
queue is what the operator also sees in System Settings.

**When a printer will not open**

* **http://localhost:9377** lists every printer on the USB bus with its address
  and, if we cannot open it, the reason. Start there.
* *"macOS would not let Fold open this printer"* — something else already has
  it. Quit the Epson/Star utility, delete the printer's queue from System
  Settings → Printers & Scanners, then unplug and replug it.
* *Windows* — the vendor driver owns the device; use the ordinary Windows
  queue (`system:…`), which already works, or swap the driver for WinUSB with
  Zadig if you really need direct access.
* *Linux* — add a udev rule for the vendor id, or put your user in `lp` /
  `plugdev`, then replug.
* *"already in use"* — a queue for the same printer is printing. Direct USB and
  a queue cannot hold the device at once.
* Nothing listed at all — the printer is off, asleep, or on a cable that is
  power-only. Vendor ids we recognise without a printer-class interface are
  Epson, Star, Bixolon, Citizen, SNBC, Zijiang and Custom; other vendors are
  only listed if they advertise a printer interface.

## Protocol

`docs/PRINT-SERVICE.md` in this repo. Four endpoints under
`/v1/agent/print`: `pair`, `heartbeat`, `jobs?wait=20` (long-poll, base64
payloads), `jobs/:id/ack`. Token in `X-Print-Agent-Token`.

## Developing

```sh
cd print-agent
npm test                 # node:test, no dependencies
FOLD_AGENT_HOME=/tmp/agent node src/cli.js run --api http://localhost:3000
```

### Building the installer

`Fold-Print-Agent-Setup.exe` is built **on Linux or macOS** — no Windows
machine involved. You need `makensis` (NSIS 3.x: `apt install nsis` /
`brew install makensis`) and `python3`; `python3 -m pip install Pillow` is
optional and only draws the icon.

```sh
cd print-agent
bash installer/build-windows.sh
# ==> Built installer/build/Fold-Print-Agent-Setup.exe   (~22 MiB)
```

The script reads the version from `package.json`, downloads the Windows Node
runtime from the npm package `node-win-x64` (caching the tarball in
`installer/build/` and verifying its sha512 against the registry's
`dist.integrity`), stages `node.exe` + `src/` + `package.json` + `README.md`,
and runs `makensis` with LZMA solid compression. It is safe to re-run; use
`CLEAN=1` to re-stage from scratch. Nothing it produces is committed —
`installer/.gitignore` covers `build/` and `*.exe`.

Details, and what the installer does on the target machine, are in
[`installer/README.md`](installer/README.md).

## Known limits

* Star WebPRNT / CloudPRNT and Epson Server Direct Print printers don't need
  the agent (they pull from the server) — that transport is not built yet.
* Windows has a one-click `.exe` installer; macOS and Linux are still
  "install Node, run a script". No code signing anywhere yet, so Windows
  SmartScreen warns on first run of the installer.
* The pairing token sits in `config.json` (mode 0600 on macOS/Linux; per-user
  AppData on Windows). Revoke from Fold POS if the computer is lost.
* Printer discovery uses the OS queue list plus the USB bus; mDNS is not done
  here.
* Direct USB is one-way: we write bytes, we do not read the printer's status
  back (paper out, cover open). A job that leaves the agent is reported as
  printed.
* Matching a USB device to an existing OS queue is done on the name, so a
  queue renamed to something unlike the printer's product string will show the
  printer twice — annoying, but safer than hiding a real printer.
