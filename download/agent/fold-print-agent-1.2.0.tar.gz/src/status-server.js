// http://localhost:9377 — a one-page status view for the shop: paired or
// not, last heartbeat, printers seen, last 20 jobs, plus a pairing form so
// nobody needs a terminal after installation. Local machine only.
import http from 'node:http';

import { AGENT_VERSION } from './config.js';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const when = (d) => (d ? new Date(d).toLocaleTimeString() : '—');

export function renderStatusPage(state, cfg, { message = '' } = {}) {
  const paired = state.paired;
  return `<!doctype html><meta charset="utf-8"><title>Fold Print Agent</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{font-family:-apple-system,Segoe UI,system-ui,sans-serif;margin:0;background:#f6f7f9;color:#0b1b2b}
main{max-width:720px;margin:32px auto;padding:0 20px}
h1{font-size:22px;margin:0 0 4px}.sub{color:#545f6b;margin:0 0 20px;font-size:14px}
.card{background:#fff;border:1px solid #e3e6e8;border-radius:12px;padding:20px;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,.04)}
.row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f0f2f4;font-size:14px}.row:last-child{border:0}
.ok{color:#007a14;font-weight:600}.bad{color:#e22d2d;font-weight:600}.muted{color:#8e969e}
input,button{font:inherit;padding:11px 14px;border-radius:10px;border:1px solid #ced4da}
button{background:#007df5;color:#fff;border:0;font-weight:600;cursor:pointer;min-height:44px}
input{min-height:44px}
table{width:100%;border-collapse:collapse;font-size:13px}td,th{text-align:left;padding:6px 4px;border-bottom:1px solid #f0f2f4}
.msg{background:#eff6ff;border:1px solid #bfdbfe;padding:10px 14px;border-radius:10px;margin-bottom:16px}
</style>
<main>
<h1>Fold Print Agent <span class="muted">v${AGENT_VERSION}</span></h1>
<p class="sub">This computer prints receipts and garment tags for Fold POS — including the browser version.</p>
${message ? `<div class="msg">${esc(message)}</div>` : ''}
<div class="card">
  <div class="row"><span>Status</span><span class="${paired && state.running ? 'ok' : 'bad'}">${paired ? (state.running ? 'Connected, waiting for jobs' : 'Paired, not running') : 'Not paired'}</span></div>
  <div class="row"><span>Server</span><span>${esc(cfg.apiBase)}</span></div>
  <div class="row"><span>Agent name</span><span>${esc(cfg.name || '—')}</span></div>
  <div class="row"><span>Last heartbeat</span><span>${when(state.lastHeartbeatAt)}</span></div>
  <div class="row"><span>Last job</span><span>${when(state.lastJobAt)}</span></div>
  <div class="row"><span>Printed / failed</span><span>${state.printed} / ${state.failed}</span></div>
  ${state.lastError ? `<div class="row"><span>Last error</span><span class="bad">${esc(state.lastError)}</span></div>` : ''}
</div>
${paired ? '' : `<div class="card"><h3 style="margin:0 0 8px">Pair this computer</h3>
<p class="muted" style="margin:0 0 12px;font-size:13px">In Fold POS go to Settings → Receipts → Fold Print Agent → "Pair with a code" and type the 6-digit code here.</p>
<form method="post" action="/pair" style="display:flex;gap:8px;flex-wrap:wrap">
<input name="code" placeholder="6-digit code" maxlength="6" pattern="[0-9]{6}" required autofocus>
<input name="name" placeholder="Name for this computer (optional)">
<input name="apiBase" placeholder="${esc(cfg.apiBase)}" value="${esc(cfg.apiBase)}" style="flex:1;min-width:220px">
<button type="submit">Pair</button></form></div>`}
<div class="card"><h3 style="margin:0 0 8px">Printers this computer can see</h3>
${state.printers.length ? `<table>${state.printers.map((p) => `<tr><td>${esc(p.name)}</td><td class="muted">${esc(p.address)}</td></tr>`).join('')}</table>` : '<p class="muted" style="margin:0">None yet — appears after the first heartbeat. Add USB printers in System Settings / Windows Settings first; LAN printers can be listed in config.json → manualPrinters.</p>'}
</div>
${renderUsbCard(state.usb)}
<div class="card"><h3 style="margin:0 0 8px">Recent jobs</h3>
${state.recent.length ? `<table><tr><th>#</th><th>Kind</th><th>Printer</th><th>Result</th></tr>${state.recent.map((j) => `<tr><td>${j.id}</td><td>${esc(j.kind)}</td><td>${esc(j.printer)}</td><td class="${j.ok ? 'ok' : 'bad'}">${j.ok ? 'printed' : esc(j.error)}</td></tr>`).join('')}</table>` : '<p class="muted" style="margin:0">No jobs yet.</p>'}
</div>
${paired ? '<form method="post" action="/unpair" onsubmit="return confirm(\'Un-pair this computer?\')"><button type="submit" style="background:#e22d2d">Un-pair this computer</button></form>' : ''}
</main>`;
}

/**
 * USB printers the OS never enumerated (most Epson TM models are vendor-class
 * and never reach CUPS). The point of this card is that a shop is never told
 * nothing: if the module is missing, or a printer is on the bus but will not
 * open, the reason is on the page.
 */
export function renderUsbCard(usb) {
  const u = usb || { loaded: false, reason: 'not checked yet', devices: [] };
  const devices = u.devices || [];
  return `<div class="card"><h3 style="margin:0 0 8px">USB printers (direct)</h3>
<div class="row"><span>Direct USB support</span><span class="${u.loaded ? 'ok' : 'muted'}">${u.loaded ? 'available' : 'off'}</span></div>
${u.loaded ? '' : `<p class="muted" style="margin:8px 0 0;font-size:13px">${esc(u.reason || 'The optional "usb" module is not installed.')}</p>`}
${devices.length
    ? `<table>${devices.map((d) => `<tr><td>${esc(d.name)}</td><td class="muted">${esc(d.address)}</td><td class="${d.error ? 'bad' : 'ok'}">${d.error ? esc(d.error) : 'can open'}</td></tr>`).join('')}</table>`
    : u.loaded
      ? '<p class="muted" style="margin:8px 0 0;font-size:13px">No USB printers on the bus. Plug the printer in and switch it on — this list does not need a driver or a queue.</p>'
      : ''}
</div>`;
}

/**
 * @param {object} opts
 * @param {() => object} opts.getState
 * @param {() => object} opts.getConfig
 * @param {(code:string, name:string, apiBase:string) => Promise<void>} opts.onPair
 * @param {() => Promise<void>} opts.onUnpair
 */
export function startStatusServer({ port, getState, getConfig, onPair, onUnpair, log = () => {} }) {
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const send = (code, body, type = 'text/html; charset=utf-8') => {
      res.writeHead(code, { 'content-type': type, 'cache-control': 'no-store' });
      res.end(body);
    };
    try {
      if (req.method === 'GET' && url.pathname === '/') return send(200, renderStatusPage(getState(), getConfig(), { message: url.searchParams.get('m') || '' }));
      if (req.method === 'GET' && url.pathname === '/status.json') {
        const s = getState();
        return send(200, JSON.stringify({ version: AGENT_VERSION, ...s, recent: s.recent.slice(0, 5) }), 'application/json');
      }
      if (req.method === 'POST' && (url.pathname === '/pair' || url.pathname === '/unpair')) {
        const body = await readBody(req);
        const form = new URLSearchParams(body);
        if (url.pathname === '/pair') {
          await onPair(form.get('code') || '', form.get('name') || '', form.get('apiBase') || '');
          res.writeHead(303, { location: '/?m=' + encodeURIComponent('Paired. Jobs will print here from now on.') });
        } else {
          await onUnpair();
          res.writeHead(303, { location: '/?m=' + encodeURIComponent('Un-paired.') });
        }
        return res.end();
      }
      send(404, 'Not found', 'text/plain');
    } catch (e) {
      log('warn', `status page: ${e.message}`);
      res.writeHead(303, { location: '/?m=' + encodeURIComponent(`Error: ${e.message}`) });
      res.end();
    }
  });
  server.listen(port, '127.0.0.1', () => log('info', `status page at http://localhost:${port}`));
  server.on('error', (e) => log('warn', `status page could not start on port ${port}: ${e.message}`));
  return server;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 10_000) reject(new Error('body too large'));
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}
