// Start-at-login installation.
//   macOS   ~/Library/LaunchAgents/com.foldpos.print-agent.plist  (launchd)
//   Windows Scheduled task "FoldPrintAgent" at logon (schtasks), falling back
//           to a launcher in the user's Startup folder when Task Scheduler
//           refuses - which it does for a standard user on Windows 11
//   Linux   ~/.config/systemd/user/fold-print-agent.service
// No admin rights needed on any of them; the agent runs as the logged-in
// user, which is also who owns the USB printer queues.
import { execFile, spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';

import { logPath } from './config.js';

const execFileP = promisify(execFile);
const LABEL = 'com.foldpos.print-agent';

export function cliPath() {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), 'cli.js');
}

export function launchdPlist({ node = process.execPath, cli = cliPath(), log = logPath() } = {}) {
  const x = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>${LABEL}</string>
  <key>ProgramArguments</key><array><string>${x(node)}</string><string>${x(cli)}</string><string>run</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>10</integer>
  <key>StandardOutPath</key><string>${x(log)}</string>
  <key>StandardErrorPath</key><string>${x(log)}</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin</string></dict>
</dict></plist>
`;
}

export function systemdUnit({ node = process.execPath, cli = cliPath() } = {}) {
  return `[Unit]
Description=Fold POS Print Agent
After=network-online.target

[Service]
ExecStart=${node} ${cli} run
Restart=always
RestartSec=5

[Install]
WantedBy=default.target
`;
}

export async function install() {
  switch (process.platform) {
    case 'darwin': {
      const dir = path.join(os.homedir(), 'Library', 'LaunchAgents');
      fs.mkdirSync(dir, { recursive: true });
      const plist = path.join(dir, `${LABEL}.plist`);
      fs.writeFileSync(plist, launchdPlist());
      await execFileP('launchctl', ['unload', plist]).catch(() => {});
      await execFileP('launchctl', ['load', '-w', plist]);
      return `Installed launch agent ${plist} — the agent now starts at login and restarts if it crashes.`;
    }
    case 'win32': {
      const cmd = `"${process.execPath}" "${cliPath()}" run`;
      try {
        await execFileP('schtasks', ['/Create', '/F', '/SC', 'ONLOGON', '/TN', 'FoldPrintAgent', '/TR', cmd, '/RL', 'LIMITED']);
        // A computer that fell back to the Startup folder on an earlier
        // install would otherwise keep both, and start two agents at the next
        // sign-in — two supervisors racing over the same update directory.
        const staleLauncher = removeStartupLauncher();
        await execFileP('schtasks', ['/Run', '/TN', 'FoldPrintAgent']).catch(() => {});
        return `Installed scheduled task "FoldPrintAgent" (runs at logon). Started it now.${
          staleLauncher ? ' Removed the old Startup shortcut, so only one agent starts.' : ''
        }`;
      } catch (err) {
        // The first real Windows 11 install hit exactly this: Task Scheduler
        // answered "Access is denied" to a standard user, the installer said
        // "start it by hand", and nothing was listening - so the POS saw no
        // printers and the person reasonably concluded the printer was the
        // problem. The Startup folder needs no permission from anyone.
        const launcher = writeStartupLauncher();
        startDetached();
        return `Task Scheduler refused (${firstLine(err)}); installed ${launcher} instead - the agent starts when you sign in. Started it now.`;
      }
    }
    default: {
      const dir = path.join(os.homedir(), '.config', 'systemd', 'user');
      fs.mkdirSync(dir, { recursive: true });
      const unit = path.join(dir, 'fold-print-agent.service');
      fs.writeFileSync(unit, systemdUnit());
      await execFileP('systemctl', ['--user', 'daemon-reload']);
      await execFileP('systemctl', ['--user', 'enable', '--now', 'fold-print-agent.service']);
      return `Installed user service ${unit}.`;
    }
  }
}

export async function uninstall() {
  switch (process.platform) {
    case 'darwin': {
      const plist = path.join(os.homedir(), 'Library', 'LaunchAgents', `${LABEL}.plist`);
      await execFileP('launchctl', ['unload', plist]).catch(() => {});
      fs.rmSync(plist, { force: true });
      return 'Removed launch agent.';
    }
    case 'win32': {
      await execFileP('schtasks', ['/End', '/TN', 'FoldPrintAgent']).catch(() => {});
      const taskGone = await execFileP('schtasks', ['/Delete', '/F', '/TN', 'FoldPrintAgent']).then(() => true, () => false);
      const launcherGone = removeStartupLauncher();
      if (!taskGone && !launcherGone) throw new Error('Nothing to remove: no scheduled task and no Startup launcher.');
      return [taskGone && 'Removed scheduled task.', launcherGone && 'Removed Startup launcher.'].filter(Boolean).join(' ');
    }
    default: {
      await execFileP('systemctl', ['--user', 'disable', '--now', 'fold-print-agent.service']).catch(() => {});
      fs.rmSync(path.join(os.homedir(), '.config', 'systemd', 'user', 'fold-print-agent.service'), { force: true });
      return 'Removed user service.';
    }
  }
}


/** The user's Startup folder - runs at sign-in with no privilege at all. */
export function startupDir({ appData = process.env.APPDATA, home = os.homedir() } = {}) {
  const base = appData || path.join(home, 'AppData', 'Roaming');
  return path.join(base, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
}

export const STARTUP_LAUNCHER = 'Fold Print Agent.cmd';

/**
 * A .cmd rather than a shortcut or a scheduled task: it needs no COM object,
 * no elevated rights and no quoting beyond the two paths. `start /min` hands
 * the agent its own minimised window and lets the launcher exit, so the
 * Startup folder does not hold a console open at sign-in.
 */
export function startupLauncherText({ node = process.execPath, cli = cliPath() } = {}) {
  return `@echo off\r\nrem Fold Print Agent - starts the print helper when you sign in.\r\nrem Installed because Windows Task Scheduler refused to create the task.\r\nstart "Fold Print Agent" /min "${node}" "${cli}" run\r\n`;
}

export function writeStartupLauncher({ dir = startupDir(), node, cli } = {}) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, STARTUP_LAUNCHER);
  fs.writeFileSync(file, startupLauncherText({ node, cli }));
  return file;
}

export function removeStartupLauncher({ dir = startupDir() } = {}) {
  const file = path.join(dir, STARTUP_LAUNCHER);
  if (!fs.existsSync(file)) return false;
  fs.rmSync(file, { force: true });
  return true;
}

/** Runs the agent now, in the background, so install does not end with "start it by hand". */
export function startDetached({ node = process.execPath, cli = cliPath() } = {}) {
  const child = spawn(node, [cli, 'run'], { detached: true, stdio: 'ignore', windowsHide: true });
  child.unref();
  return child.pid;
}

function firstLine(err) {
  const text = String(err?.stderr || err?.message || err || '').trim();
  return text.split(/\r?\n/)[0] || 'unknown error';
}
