// Thin client for the four agent endpoints (docs/PRINT-SERVICE.md):
//   POST /v1/agent/print/pair            { pairingCode, name, platform, version }
//   POST /v1/agent/print/heartbeat       X-Print-Agent-Token   { version, printers[] }
//   GET  /v1/agent/print/jobs?wait=20    X-Print-Agent-Token   → { jobs[] }
//   POST /v1/agent/print/jobs/:id/ack    X-Print-Agent-Token   { ok, error? }

export class ApiError extends Error {
  constructor(message, status, body) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

export class FoldApi {
  /**
   * @param {object} opts
   * @param {string} opts.apiBase   e.g. https://app.foldpos.com
   * @param {string|null} opts.token
   * @param {typeof fetch} [opts.fetchImpl]
   */
  constructor({ apiBase, token = null, fetchImpl = globalThis.fetch }) {
    this.apiBase = apiBase;
    this.token = token;
    this.fetch = fetchImpl;
  }

  url(p) {
    return `${this.apiBase}/v1/agent/print${p}`;
  }

  async request(method, p, { body, timeoutMs = 30_000, auth = true } = {}) {
    const headers = { accept: 'application/json' };
    if (body !== undefined) headers['content-type'] = 'application/json';
    if (auth) {
      if (!this.token) throw new ApiError('Agent is not paired', 401, null);
      headers['x-print-agent-token'] = this.token;
    }
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    let res;
    try {
      res = await this.fetch(this.url(p), {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: ctrl.signal,
      });
    } catch (e) {
      throw new ApiError(e.name === 'AbortError' ? `Timed out calling ${method} ${p}` : `Network error: ${e.message}`, 0, null);
    } finally {
      clearTimeout(timer);
    }
    const text = await res.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }
    if (!res.ok) {
      const msg = json?.message ?? json?.error ?? text ?? res.statusText;
      throw new ApiError(`${method} ${p} → ${res.status}: ${Array.isArray(msg) ? msg.join('; ') : msg}`, res.status, json);
    }
    // The API wraps every response as { success, message, data }.
    if (json && typeof json === 'object' && typeof json.success === 'boolean' && 'data' in json) {
      if (!json.success) throw new ApiError(`${method} ${p}: ${json.message ?? 'request failed'}`, res.status, json);
      return json.data;
    }
    return json;
  }

  /** @returns {Promise<{agentId:number, businessId:number, token:string}>} */
  pair({ pairingCode, name, platform, version }) {
    return this.request('POST', '/pair', { body: { pairingCode, name, platform, version }, auth: false });
  }

  heartbeat({ version, printers }) {
    return this.request('POST', '/heartbeat', { body: { version, printers } });
  }

  /** Long-poll; resolves with [] after `wait` seconds when nothing is queued. */
  async claimJobs(wait) {
    const res = await this.request('GET', `/jobs?wait=${Math.max(0, Math.min(25, wait | 0))}`, {
      timeoutMs: (wait + 15) * 1000,
    });
    return Array.isArray(res?.jobs) ? res.jobs : [];
  }

  ack(jobId, ok, error) {
    return this.request('POST', `/jobs/${jobId}/ack`, { body: error ? { ok, error: String(error).slice(0, 2000) } : { ok } });
  }
}
