// The little process that keeps the agent running, and is how an update takes
// effect.
//
// The installer registers one command — `node.exe src\cli.js run` — in a
// logon task, and that never changes again. What changes is which copy of the
// agent code that command runs:
//
//   apps/1.3.0/src/cli.js   ← what wanted.json names, if it starts
//   apps/1.2.0/src/cli.js   ← the last one that worked
//   <installed>/src/cli.js  ← what the installer put down; always the floor
//
// It also fixes something that predates updating at all: on Windows the agent
// is started by a logon task, so a crash left the shop with no printing until
// somebody rebooted. The supervisor restarts it.
//
// Fallback is the part that has to be right, because nobody is watching. A
// version that exits within [MIN_HEALTHY_MS] is suspect; twice and it is
// written off, the shop goes back to the version below it, and the server is
// told what happened the next time the older agent reports its version.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

import { appsDir } from './config.js';
import { RESTART_EXIT_CODE, compareVersions, installedVersions } from './update.js';

/** A child that dies sooner than this did not really start. */
export const MIN_HEALTHY_MS = 20_000;
/** Strikes before a version is written off. */
export const STRIKES = 2;

/** Beside the versions it is about, so a test can point it somewhere else. */
export function badVersionsPath(dir = appsDir()) {
  return path.join(dir, 'bad-versions.json');
}

export function readBad(dir = appsDir()) {
  try {
    return JSON.parse(fs.readFileSync(badVersionsPath(dir), 'utf8'));
  } catch {
    return {};
  }
}

export function writeBad(bad, dir = appsDir()) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(badVersionsPath(dir), JSON.stringify(bad, null, 2));
  } catch {
    /* a forgotten strike costs one more restart, nothing worse */
  }
}

export function lockPath(dir = appsDir()) {
  return path.join(dir, 'supervisor.pid');
}

/**
 * Is another supervisor already running on this computer? Two of them race
 * over the same update directory and double-count strikes. Best effort: a pid
 * file, and `process.kill(pid, 0)` to see whether that process is still there.
 */
export function anotherSupervisorIsRunning(dir = appsDir(), { alive = isAlive } = {}) {
  try {
    const pid = Number(JSON.parse(fs.readFileSync(lockPath(dir), 'utf8'))?.pid);
    if (!pid || pid === process.pid) return false;
    return alive(pid);
  } catch {
    return false;
  }
}

export function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    // EPERM means it exists and belongs to somebody else.
    return e.code === 'EPERM';
  }
}

export function claimLock(dir = appsDir()) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(lockPath(dir), JSON.stringify({ pid: process.pid, at: new Date().toISOString() }));
  } catch {
    /* a lock we cannot write is a guard we do without */
  }
}

export function readWanted(dir = appsDir()) {
  try {
    return JSON.parse(fs.readFileSync(path.join(dir, 'wanted.json'), 'utf8'))?.version ?? null;
  } catch {
    return null;
  }
}

/**
 * Which copy to run: the wanted version if it is unpacked and not written off,
 * else the newest unpacked one that is not written off, else the installed
 * copy. Pure, given the lists.
 *
 * @returns {{version: string|null, reason: string}} version null = the installed copy
 */
export function chooseVersion({ wanted, installed = [], bad = {}, floor = null } = {}) {
  const usable = installed
    .filter((v) => (bad[v]?.strikes ?? 0) < STRIKES)
    .filter((v) => !floor || compareVersions(v, floor) > 0)
    .sort(compareVersions);
  if (wanted && usable.includes(wanted)) return { version: wanted, reason: 'wanted' };
  const newest = usable[usable.length - 1];
  if (wanted && !usable.includes(wanted)) {
    if ((bad[wanted]?.strikes ?? 0) >= STRIKES) {
      return newest
        ? { version: newest, reason: `${wanted} was written off` }
        : { version: null, reason: `${wanted} was written off` };
    }
    // Named but not unpacked — a half-finished update. Carry on without it.
  }
  return newest
    ? { version: newest, reason: 'newest unpacked' }
    : { version: null, reason: 'nothing unpacked' };
}

/**
 * Run the agent, for ever, restarting it as needed.
 *
 * @param {object} deps
 * @param {string[]} deps.argv       arguments to pass the child after `run`
 * @param {string} [deps.node]       node binary (defaults to this one)
 * @param {string} deps.installedCli path of the installed cli.js (the floor)
 * @param {(level:string,msg:string)=>void} [deps.log]
 * @param {typeof spawn} [deps.spawn]
 * @param {() => number} [deps.now]
 * @param {(ms:number)=>Promise<void>} [deps.sleep]
 * @param {number} [deps.maxRuns]    tests stop it; unset means never
 */
export async function supervise(deps) {
  const {
    argv = [],
    node = process.execPath,
    installedCli,
    installedVersion = null,
    log = () => {},
    spawn: spawnImpl = spawn,
    now = () => Date.now(),
    sleep = (ms) => new Promise((r) => setTimeout(r, ms)),
    dir = appsDir(),
    maxRuns = Infinity,
  } = deps;
  if (
    deps.checkLock !== false &&
    anotherSupervisorIsRunning(deps.dir ?? appsDir(), deps.alive ? { alive: deps.alive } : {})
  ) {
    (deps.log ?? (() => {}))('warn', 'another Fold agent is already running on this computer; leaving it to it');
    return 0;
  }
  claimLock(deps.dir ?? appsDir());
  let runs = 0;
  let backoff = 2000;
  let stopping = false;
  while (runs < maxRuns) {
    runs += 1;
    const bad = readBad(dir);
    const choice = chooseVersion({
      wanted: readWanted(dir),
      installed: installedVersions(dir),
      bad,
      floor: installedVersion,
    });
    const cli = choice.version ? path.join(dir, choice.version, 'src', 'cli.js') : installedCli;
    const label = choice.version ? `${choice.version} (${choice.reason})` : 'the installed copy';
    log('info', `starting the agent from ${label}`);

    const startedAt = now();
    const outcome = await new Promise((resolve) => {
      const child = spawnImpl(node, [cli, 'run', ...argv], {
        stdio: 'inherit',
        env: { ...process.env, FOLD_AGENT_CHILD: '1' },
        windowsHide: true,
      });
      const done = (value) => {
        process.off('SIGINT', onSignal);
        process.off('SIGTERM', onSignal);
        resolve(value);
      };
      function onSignal() {
        // Asked to stop: stop, and do not hold the exit against the version.
        stopping = true;
        try {
          child.kill();
        } catch {
          /* already gone */
        }
      }
      child.on('error', (e) => {
        log('error', `could not start ${label}: ${e.message}`);
        done({ code: -1, signal: null, failedToStart: true });
      });
      child.on('exit', (code, signal) => done({ code: code ?? 0, signal }));
      process.on('SIGINT', onSignal);
      process.on('SIGTERM', onSignal);
    });
    const { code, signal } = outcome;
    // A clock that stepped backwards must not read as an instant crash.
    const lived = Math.max(0, now() - startedAt);

    if (stopping) {
      log('info', 'stopping');
      break;
    }
    if (code === RESTART_EXIT_CODE) {
      log('info', 'the agent updated itself; starting the new version');
      backoff = 2000;
      // A moment for the status port to be released before the new one binds.
      await sleep(500);
      continue;
    }
    // Signalled, or a clean exit: somebody stopped it. Only a version that
    // falls over on its own earns a strike — a shop signing out of Windows
    // twice must not cost it the version it is running.
    const crashed = !signal && code !== 0;
    if (choice.version && crashed && lived < MIN_HEALTHY_MS) {
      const strikes = (bad[choice.version]?.strikes ?? 0) + 1;
      bad[choice.version] = { strikes, lastExit: code, at: new Date(now()).toISOString() };
      writeBad(bad, dir);
      log(
        'warn',
        strikes >= STRIKES
          ? `${choice.version} exited after ${Math.round(lived / 1000)}s twice — going back to the version below it`
          : `${choice.version} exited after ${Math.round(lived / 1000)}s (strike ${strikes})`,
      );
    } else if (choice.version && lived >= MIN_HEALTHY_MS) {
      // It ran properly this time; forget any old strike, and stop backing off.
      if (bad[choice.version]) {
        delete bad[choice.version];
        writeBad(bad, dir);
      }
      backoff = 2000;
    }
    if (runs >= maxRuns) break;
    await sleep(backoff);
    backoff = Math.min(backoff * 2, 60_000);
  }
  return runs;
}
