// The run loop: heartbeat every N seconds, long-poll for jobs, print, ack.
// Never throws out of `run()`; every failure is logged and retried with
// backoff. A 401 means the token was revoked — the loop stops and the status
// page says "not paired".
import os from 'node:os';

import { ApiError, FoldApi } from './api.js';
import { AGENT_VERSION } from './config.js';
import { discoverPrinters, print, usbStatus } from './printers/index.js';
import { applyUpdate } from './update.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function platformName() {
  switch (process.platform) {
    case 'darwin':
      return 'macos';
    case 'win32':
      return 'windows';
    default:
      return process.platform;
  }
}

export function defaultAgentName() {
  return `${os.hostname()} (${platformName()})`;
}

export class Agent {
  /**
   * @param {object} cfg   loaded config (see config.js)
   * @param {object} [deps]
   * @param {FoldApi} [deps.api]
   * @param {(level:string, msg:string, extra?:object)=>void} [deps.log]
   * @param {typeof print} [deps.print]
   * @param {typeof discoverPrinters} [deps.discover]
   * @param {typeof applyUpdate} [deps.applyUpdate]
   * @param {(ms:number)=>Promise<void>} [deps.sleep]
   */
  constructor(cfg, deps = {}) {
    this.cfg = cfg;
    this.api = deps.api ?? new FoldApi({ apiBase: cfg.apiBase, token: cfg.token });
    this.log = deps.log ?? (() => {});
    this.printImpl = deps.print ?? print;
    this.discoverImpl = deps.discover ?? discoverPrinters;
    this.usbStatusImpl = deps.usbStatus ?? usbStatus;
    this.updateImpl = deps.applyUpdate ?? applyUpdate;
    this.sleep = deps.sleep ?? sleep;
    this.stopped = false;
    this.state = {
      paired: Boolean(cfg.token),
      running: false,
      lastHeartbeatAt: null,
      lastJobAt: null,
      lastError: null,
      printed: 0,
      failed: 0,
      printers: [],
      usb: { loaded: false, reason: 'not checked yet', devices: [] },
      /** The newer version the server last offered, if any. */
      updateOffer: null,
      /** Set when a new version is unpacked and this process is handing over. */
      updatedTo: null,
      recent: [], // last 20 jobs: {id, kind, printer, ok, error, at}
    };
  }

  stop() {
    this.stopped = true;
  }

  async heartbeat() {
    try {
      // One bus scan per heartbeat, shared by discovery and the status page.
      this.state.usb = await this.usbStatusImpl();
      this.state.printers = await this.discoverImpl({ manual: this.cfg.manualPrinters || [], usbDevices: this.state.usb.devices });
    } catch (e) {
      this.log('warn', `printer discovery failed: ${e.message}`);
    }
    try {
      const res = await this.api.heartbeat({ version: AGENT_VERSION, printers: this.state.printers });
      this.state.lastHeartbeatAt = new Date();
      this.state.lastError = null;
      // What this computer should be running, if it is behind. Kept for the
      // run loop to act on between jobs — never here, mid-heartbeat, with a
      // receipt possibly half printed.
      this.state.updateOffer = res?.update ?? null;
      return true;
    } catch (e) {
      this.state.lastError = e.message;
      this.log('warn', `heartbeat failed: ${e.message}`);
      if (e instanceof ApiError && e.status === 401) this.state.paired = false;
      return false;
    }
  }

  async handleJob(job) {
    this.state.lastJobAt = new Date();
    const entry = { id: job.id, kind: job.kind, printer: job.printer?.name, ok: false, error: null, at: new Date() };
    let ok = false;
    let error = null;
    try {
      const bytes = Buffer.from(job.payloadBase64 || '', 'base64');
      if (!bytes.length) throw new Error('Job payload is empty');
      const status = await this.printImpl(job.printer, bytes, {
        copies: job.copies || 1,
        title: `Fold POS ${job.kind} #${job.id}`,
      });
      ok = true;
      this.state.printed += 1;
      this.log('info', `job ${job.id} ${job.kind} → ${job.printer?.name}: ${status}`);
    } catch (e) {
      error = e.message;
      this.state.failed += 1;
      this.state.lastError = `job ${job.id}: ${e.message}`;
      this.log('error', `job ${job.id} ${job.kind} → ${job.printer?.name} FAILED: ${e.message}`);
    }
    entry.ok = ok;
    entry.error = error;
    this.state.recent.unshift(entry);
    if (this.state.recent.length > 20) this.state.recent.length = 20;
    try {
      await this.api.ack(job.id, ok, error);
    } catch (e) {
      this.log('warn', `ack for job ${job.id} failed: ${e.message}`);
    }
    return ok;
  }

  /** One long-poll → print → ack cycle. Returns the number of jobs handled. */
  async pollOnce() {
    const jobs = await this.api.claimJobs(this.cfg.waitSeconds ?? 20);
    for (const job of jobs) {
      if (this.stopped) break;
      await this.handleJob(job);
    }
    return jobs.length;
  }

  /**
   * Act on an update the server offered, if there is one. True means a new
   * version is unpacked and this process should hand over to it — the caller
   * stops the loop and exits with [RESTART_EXIT_CODE] so the supervisor starts
   * the new one. False means carry on exactly as before, which is what every
   * failure here amounts to.
   */
  async maybeUpdate() {
    const offer = this.state.updateOffer;
    if (!offer) return false;
    this.state.updateOffer = null;
    if (this.cfg.autoUpdate === false) return false;
    const result = await this.updateImpl(offer, {
      log: this.log,
      autoUpdate: this.cfg.autoUpdate !== false,
    }).catch((e) => {
      // applyUpdate does not throw, but a surprise here must not take the
      // agent down with it.
      this.log('warn', `update failed: ${e.message || e}`);
      return { applied: false };
    });
    if (!result?.applied) return false;
    this.state.updatedTo = result.version;
    this.stopped = true;
    return true;
  }

  async run() {
    if (!this.cfg.token) {
      this.log('warn', 'not paired — run `fold-print-agent pair <code>` or open the status page');
      return;
    }
    this.state.running = true;
    this.log('info', `agent ${AGENT_VERSION} starting on ${platformName()} → ${this.cfg.apiBase}`);
    let nextHeartbeat = 0;
    let backoff = 2000;
    while (!this.stopped) {
      if (Date.now() >= nextHeartbeat) {
        await this.heartbeat();
        nextHeartbeat = Date.now() + (this.cfg.heartbeatSeconds ?? 60) * 1000;
        if (!this.state.paired) break;
      }
      try {
        await this.pollOnce();
        backoff = 2000;
        // Between jobs is the only safe moment to replace ourselves: a poll
        // has just returned, nothing is on its way to a printer.
        if (await this.maybeUpdate()) break;
      } catch (e) {
        this.state.lastError = e.message;
        if (e instanceof ApiError && e.status === 401) {
          this.log('error', 'token rejected by the server — this computer was un-paired');
          this.state.paired = false;
          break;
        }
        this.log('warn', `poll failed: ${e.message} — retrying in ${backoff / 1000}s`);
        await this.sleep(backoff);
        backoff = Math.min(backoff * 2, 60_000);
      }
    }
    this.state.running = false;
    this.log('info', 'agent stopped');
  }
}
