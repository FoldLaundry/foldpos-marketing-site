// Where the agent keeps its pairing token and settings.
//
//   macOS    ~/Library/Application Support/FoldPrintAgent/config.json
//   Windows  %APPDATA%\FoldPrintAgent\config.json
//   Linux    ~/.config/fold-print-agent/config.json
//
// The token is a per-computer credential (revokable from Fold POS →
// Settings → Receipts → Print agents). File is created 0600 on POSIX.

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export const DEFAULT_API = 'https://app.foldpos.com';
export const DEFAULT_STATUS_PORT = 9377;
export const AGENT_VERSION = '1.2.0';

export function configDir() {
  if (process.env.FOLD_AGENT_HOME) return process.env.FOLD_AGENT_HOME;
  switch (process.platform) {
    case 'darwin':
      return path.join(os.homedir(), 'Library', 'Application Support', 'FoldPrintAgent');
    case 'win32':
      return path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'FoldPrintAgent');
    default:
      return path.join(process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config'), 'fold-print-agent');
  }
}

export function configPath() {
  return path.join(configDir(), 'config.json');
}

/**
 * Where updated copies of the agent live: `apps/<version>/src/...`, under the
 * user's own data folder, so an update needs no installer and no admin. The
 * copy the installer put down is never touched and is always the fallback.
 */
export function appsDir() {
  return path.join(configDir(), 'apps');
}

export function logPath() {
  return path.join(configDir(), 'agent.log');
}

export const defaults = Object.freeze({
  apiBase: DEFAULT_API,
  token: null,
  agentId: null,
  businessId: null,
  name: null,
  statusPort: DEFAULT_STATUS_PORT,
  /** Long-poll hold time asked of the server (0–25 s). */
  waitSeconds: 20,
  /** Heartbeat interval in seconds. */
  heartbeatSeconds: 60,
  /** Extra printers the OS can't discover (LAN printers): [{name, address:"host:9100"}]. */
  manualPrinters: [],
  /**
   * Let the agent update itself when the server offers a newer version. A
   * shop that wants to stay put sets this to false; the server can also stop
   * offering, which is how a bad release is stopped everywhere at once.
   */
  autoUpdate: true,
});

export function loadConfig() {
  try {
    const raw = fs.readFileSync(configPath(), 'utf8');
    return { ...defaults, ...JSON.parse(raw) };
  } catch (e) {
    if (e.code === 'ENOENT') return { ...defaults };
    throw new Error(`Could not read ${configPath()}: ${e.message}`);
  }
}

export function saveConfig(cfg) {
  fs.mkdirSync(configDir(), { recursive: true });
  const tmp = `${configPath()}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, configPath());
}

/** Normalises a user-typed API base: strips trailing slashes and `/v1`. */
export function normalizeApiBase(input) {
  let s = String(input || DEFAULT_API).trim();
  if (!/^https?:\/\//i.test(s)) s = `https://${s}`;
  s = s.replace(/\/+$/, '');
  s = s.replace(/\/v1$/, '');
  return s;
}
