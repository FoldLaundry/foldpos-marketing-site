#!/usr/bin/env node
// fold-print-agent — see README.md
//
//   fold-print-agent pair <code> [--name "Front counter"] [--api https://app.foldpos.com]
//   fold-print-agent run                 (foreground; status page on http://localhost:9377)
//   fold-print-agent status
//   fold-print-agent printers            (what this computer can see)
//   fold-print-agent test <queue|host:port|usb:04b8:0202>   (prints a short ESC/POS test slip)
//   fold-print-agent install-service | uninstall-service
//   fold-print-agent unpair
import fs from 'node:fs';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

import { Agent, defaultAgentName, platformName } from './agent.js';
import { FoldApi } from './api.js';
import { AGENT_VERSION, configPath, loadConfig, logPath, normalizeApiBase, saveConfig } from './config.js';
import { discoverPrinters, print, usbStatus } from './printers/index.js';
import { install, uninstall } from './service.js';
import { startStatusServer } from './status-server.js';
import { normalizePairingCode, pairFromInstaller } from './installer-name.js';
import { RESTART_EXIT_CODE } from './update.js';

function parseArgs(argv) {
  const args = { _: [], flags: {} };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const [k, v] = a.slice(2).split('=');
      if (v !== undefined) args.flags[k] = v;
      else if (argv[i + 1] !== undefined && !argv[i + 1].startsWith('--')) args.flags[k] = argv[++i];
      else args.flags[k] = true;
    } else args._.push(a);
  }
  return args;
}

function makeLogger() {
  let stream = null;
  try {
    fs.mkdirSync(require_dirname(logPath()), { recursive: true });
    stream = fs.createWriteStream(logPath(), { flags: 'a' });
  } catch {
    stream = null;
  }
  return (level, msg) => {
    const line = `${new Date().toISOString()} ${level.padEnd(5)} ${msg}`;
    (level === 'error' || level === 'warn' ? console.error : console.log)(line);
    stream?.write(line + '\n');
  };
}

/** This copy's own cli.js — the floor the supervisor falls back to. */
function cliPathOfThisCopy() {
  return fileURLToPath(import.meta.url);
}

function require_dirname(p) {
  return p.slice(0, Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')));
}

async function doPair(cfg, code, name, apiBase, log) {
  const clean = normalizePairingCode(code);
  if (!clean) throw new Error('The pairing code is 6 digits (Fold POS → Settings → Receipts → Fold Print Agent → "Pair with a code")');
  const base = normalizeApiBase(apiBase || cfg.apiBase);
  const label = (name || cfg.name || defaultAgentName()).trim();
  const api = new FoldApi({ apiBase: base });
  const res = await api.pair({ pairingCode: clean, name: label, platform: platformName(), version: AGENT_VERSION });
  if (!res?.token) throw new Error('Server did not return a token');
  const next = { ...cfg, apiBase: base, token: res.token, agentId: res.agentId ?? null, businessId: res.businessId ?? null, name: label };
  saveConfig(next);
  log('info', `paired as agent #${res.agentId} "${label}" with ${base}`);
  return next;
}

const ESC_POS_TEST = Buffer.concat([
  Buffer.from([0x1b, 0x40]), // init
  Buffer.from([0x1b, 0x61, 0x01]), // center
  Buffer.from('FOLD POS\n', 'ascii'),
  Buffer.from([0x1b, 0x61, 0x00]),
  Buffer.from(`Print agent test ${new Date().toLocaleString()}\nIf you can read this, the agent can reach this printer.\n\n\n`, 'ascii'),
  Buffer.from([0x1d, 0x56, 0x42, 0x00]), // partial cut
]);

async function main() {
  const { _: pos, flags } = parseArgs(process.argv.slice(2));
  const cmd = pos[0] || 'run';
  const log = makeLogger();
  let cfg = loadConfig();
  if (flags.api) cfg.apiBase = normalizeApiBase(flags.api);

  switch (cmd) {
    case 'pair': {
      cfg = await doPair(cfg, pos[1], flags.name, flags.api, log);
      console.log(`Paired. Start it with: fold-print-agent run   (or install-service to run at login)`);
      return;
    }
    case 'pair-from-installer': {
      const { code: exit, message } = await pairFromInstaller(cfg, pos[1], {
        makeApi: (opts) => new FoldApi(opts),
        pair: (c, code) => doPair(c, code, flags.name, flags.api, log),
        saveConfig,
        log,
      });
      console.log(message);
      process.exitCode = exit;
      return;
    }
    case 'unpair': {
      saveConfig({ ...cfg, token: null, agentId: null, businessId: null });
      console.log('Un-paired (revoke the agent in Fold POS → Settings → Receipts too).');
      return;
    }
    case 'status': {
      console.log(JSON.stringify({ version: AGENT_VERSION, platform: platformName(), config: configPath(), apiBase: cfg.apiBase, paired: Boolean(cfg.token), agentId: cfg.agentId, name: cfg.name, log: logPath() }, null, 2));
      return;
    }
    case 'printers': {
      const usb = await usbStatus();
      const list = await discoverPrinters({ manual: cfg.manualPrinters || [], usbDevices: usb.devices });
      if (!list.length) console.log('No printers found. Add the USB printer in your OS printer settings, or list LAN printers in config.json → manualPrinters.');
      for (const p of list) console.log(`${p.name.padEnd(32)} ${p.address}`);
      if (!usb.loaded) console.log(`\n${usb.reason}`);
      for (const d of usb.devices) if (d.error) console.log(`\n${d.name} (${d.address}): ${d.error}`);
      return;
    }
    case 'ask': {
      // "Is the printer OK?" answered by the printer itself, over ESC/POS
      // DLE EOT. This is the question support always has to ask over the
      // phone — out of paper? cover open? — and now it can be answered.
      const target = pos[1];
      if (!target) throw new Error('Usage: fold-print-agent ask usb:04b8:0202');
      if (!/^usb:/i.test(target)) throw new Error('Only USB printers can be asked directly. Queues and LAN printers do not report back.');
      const { queryStatus } = await import('./printers/usb.js');
      const st = await queryStatus(target);
      if (!st.known) { console.log(`Could not tell: ${st.reason}`); return; }
      console.log(st.ok ? 'The printer is ready.' : `Not ready — ${st.message}.`);
      return;
    }
    case 'test': {
      const target = pos[1];
      if (!target) throw new Error('Usage: fold-print-agent test <queue name | host:port>');
      const isNetwork = !/^usb:/i.test(target) && (/^[\w.-]+:\d+$/.test(target) || /^network:/i.test(target));
      const printer = isNetwork ? { name: target, transport: 'NETWORK', address: target } : { name: target, transport: 'AGENT', address: target };
      console.log(await print(printer, ESC_POS_TEST, { title: 'Fold POS test' }));
      return;
    }
    case 'install-service':
      console.log(await install());
      return;
    case 'uninstall-service':
      console.log(await uninstall());
      return;
    case 'run': {
      // One command, two jobs. Started by the logon task or by hand, this
      // process supervises: it runs the newest verified copy of the agent and
      // restarts it, which is also how an update takes effect. Re-entered as
      // the child (FOLD_AGENT_CHILD), it is the agent itself.
      if (!process.env.FOLD_AGENT_CHILD && !flags['no-supervisor']) {
        const { supervise } = await import('./supervisor.js');
        await supervise({
          argv: flags.port ? ['--port', String(flags.port)] : [],
          installedCli: cliPathOfThisCopy(),
          installedVersion: AGENT_VERSION,
          log,
        });
        return;
      }
      let agent = new Agent(cfg, { log });
      const server = startStatusServer({
        port: Number(flags.port || cfg.statusPort || 9377),
        log,
        getState: () => agent.state,
        getConfig: () => cfg,
        onPair: async (code, name, apiBase) => {
          cfg = await doPair(cfg, code, name, apiBase, log);
          agent.stop();
          agent = new Agent(cfg, { log });
          agent.run().catch((e) => log('error', `agent crashed: ${e.stack || e}`));
        },
        onUnpair: async () => {
          agent.stop();
          cfg = { ...cfg, token: null, agentId: null, businessId: null };
          saveConfig(cfg);
          agent = new Agent(cfg, { log });
        },
      });
      const shutdown = () => {
        log('info', 'shutting down');
        agent.stop();
        server.close();
        setTimeout(() => process.exit(0), 500).unref();
      };
      process.on('SIGINT', shutdown);
      process.on('SIGTERM', shutdown);
      await agent.run();
      if (agent.state.updatedTo) {
        // Hand over to the version just unpacked. The supervisor is watching
        // for this code and starts it; anything else would leave the shop on
        // the old one until the next logon.
        log('info', `handing over to ${agent.state.updatedTo}`);
        server.close();
        process.exit(RESTART_EXIT_CODE);
      }
      if (!agent.state.paired) log('info', 'waiting for pairing on the status page');
      // Keep the process alive for the status page even when not paired.
      await new Promise(() => {});
      return;
    }
    default:
      console.log(`fold-print-agent ${AGENT_VERSION}\n\n  pair <code> [--name N] [--api URL]\n  run [--port 9377]\n  status\n  printers\n  test <queue | host:port>\n  install-service | uninstall-service\n  unpair`);
  }
}

main().catch((e) => {
  console.error(e.message || e);
  process.exit(1);
});
