// macOS / Linux: CUPS. Raw bytes go through `lp -o raw`, which hands the
// ESC/POS / ZPL stream to the queue untouched. Discovery is `lpstat -p`.
import { execFile } from 'node:child_process';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';

const execFileP = promisify(execFile);

export async function listQueues() {
  let queues = [];
  try {
    const { stdout } = await execFileP('lpstat', ['-p'], { timeout: 5000 });
    queues = parseLpstat(stdout);
  } catch {
    return [];
  }
  // Also ask what device each queue points at. For a USB printer the URI
  // carries the serial number, which is the only exact way to tell that a
  // queue and a device on the USB bus are the same physical printer —
  // matching their names is guesswork and gets a renamed queue wrong.
  try {
    const { stdout } = await execFileP('lpstat', ['-v'], { timeout: 5000 });
    const uris = parseLpstatDevices(stdout);
    for (const q of queues) {
      const uri = uris.get(q.name);
      if (!uri) continue;
      q.deviceUri = uri;
      q.deviceSerial = serialFromDeviceUri(uri);
    }
  } catch {
    /* no URIs — fall back to name matching */
  }
  return queues;
}

/** `printer Epson_TM_T20 is idle.  enabled since …` → [{ name, status }] */
export function parseLpstat(stdout) {
  const out = [];
  for (const line of String(stdout).split('\n')) {
    const m = /^printer\s+(\S+)\s+(?:is\s+)?(.*)$/i.exec(line.trim());
    if (m) out.push({ name: m[1], status: m[2].replace(/\.\s*$/, '').trim() });
  }
  return out;
}

/** `device for Epson_TM_T20: usb://EPSON/TM-T20?serial=X` → Map(name → uri) */
export function parseLpstatDevices(stdout) {
  const out = new Map();
  for (const line of String(stdout).split('\n')) {
    const m = /^device for\s+([^:]+):\s*(\S.*)$/i.exec(line.trim());
    if (m) out.set(m[1].trim(), m[2].trim());
  }
  return out;
}

/**
 * The serial out of a CUPS device URI. CUPS writes USB printers as
 * `usb://EPSON/TM-T20II?serial=583037374030910100`, sometimes with the serial
 * percent-encoded and sometimes spelled `uuid=`. Returns null for network,
 * dnssd and anything else without one.
 */
export function serialFromDeviceUri(uri) {
  const s = String(uri ?? '');
  const m = /[?&](?:serial|uuid)=([^&\s]+)/i.exec(s);
  if (!m) return null;
  try {
    return decodeURIComponent(m[1]).trim() || null;
  } catch {
    return m[1].trim() || null;
  }
}

/** Sends raw bytes to a CUPS queue. Resolves with the job id text from lp. */
export async function sendRaw(queue, bytes, { title = 'Fold POS' } = {}) {
  const q = String(queue || '').replace(/^system:/i, '').trim();
  if (!q) throw new Error('Printer queue name is empty');
  const tmp = path.join(os.tmpdir(), `fold-print-${process.pid}-${Date.now()}.bin`);
  await fs.writeFile(tmp, bytes);
  try {
    const { stdout } = await execFileP('lp', ['-d', q, '-o', 'raw', '-t', title, tmp], { timeout: 20_000 });
    return stdout.trim();
  } catch (e) {
    const msg = (e.stderr || e.message || '').toString().trim();
    throw new Error(`lp failed for queue "${q}": ${msg}`);
  } finally {
    fs.unlink(tmp).catch(() => {});
  }
}
