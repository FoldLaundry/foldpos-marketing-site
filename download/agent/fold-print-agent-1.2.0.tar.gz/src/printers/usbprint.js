// Windows: a USB printer with NO queue, printed to directly.
//
// Plug a receipt or tag printer into a Windows PC and the in-box `usbprint`
// class driver binds it and exposes a device interface
// (\\?\USB#VID_1504&PID_0059#<instance>#{28d78fad-5a12-11d1-ae5b-0000f803a8c2})
// — whether or not anybody ever adds a printer queue for it. Opening that
// path for writing and pushing ESC/POS bytes through prints, as a standard
// user, with nothing installed. Proven on the Blvd Cleaners counter PC with
// a Bixolon SRP-275III on Sep 21 2026 — first with kernel32 P/Invoke from
// PowerShell, then with plain Node `fs.openSync(path, 'w')` + `writeSync`,
// which map to CreateFileW/WriteFile directly. (An earlier comment here said
// Node's fs would not open device paths; that was wrong.)
//
// This is the "plug it in and it's in Fold POS" path: the heartbeat reports
// each such printer by its Windows product name, the POS offers it under Add
// printer (or the server sets it up by itself), and jobs are written straight
// to the interface. Enumeration reads the registry with `reg.exe`
// (usbprint-registry.js); writing is Node fs (usbprint-write.js). No
// PowerShell, no native module, so the installer stays what it is.
//
// Addresses: `usb:VID_1504&PID_0059&<instance>` — the ids Windows writes and
// the USB instance id, which is the printer's serial number when it has one
// and a bus position otherwise. The interface path is looked up fresh from
// the registry at print time, so a printer moved to another port still
// prints (the only printer of that model is taken to be the one meant).
import { devicePathForAddress, listDevices as listRegistryDevices } from './usbprint-registry.js';
import { sendRaw as writeRaw } from './usbprint-write.js';

export { USBPRINT_INTERFACE_GUID, PRINTER_VENDORS, parseDevicePath } from './usbprint-registry.js';

/** `usb:VID_1504&PID_0059&<instance>` — a Windows usbprint address (vs. `usb:04b8:0059` for the libusb backend). */
export function isUsbPrintAddress(address) {
  return /^usb:VID_[0-9a-f]{4}&PID_[0-9a-f]{4}&/i.test(String(address ?? '').trim());
}

export function formatUsbPrintAddress(vendorId, productId, instance) {
  return `usb:VID_${String(vendorId).toUpperCase()}&PID_${String(productId).toUpperCase()}&${instance}`;
}

/**
 * Printers Windows' usbprint class driver is bound to right now, as the
 * heartbeat reports them: `{ name, address, kind: 'usb', vendorId, productId, instance, path }`.
 * Never throws; `[]` off Windows.
 */
export async function listDevices({ query } = {}) {
  if (process.platform !== 'win32' && !query) return [];
  const devices = await listRegistryDevices({ query });
  return devices.map((d) => ({
    name: d.name,
    address: d.address,
    kind: 'usb',
    product: d.name,
    vendorId: d.vendorId,
    productId: d.productId,
    instance: d.instance,
    path: d.devicePath,
  }));
}

/**
 * Writes the bytes to the printer behind a `usb:VID_…` address. The device
 * path is resolved from the registry every time — cheap, and the only way a
 * printer that changed ports keeps working.
 */
export async function sendRaw(address, bytes, { query, fs } = {}) {
  if (!isUsbPrintAddress(address)) {
    throw new Error(`"${address}" is not a USB printer address (expected usb:VID_1504&PID_0059&<instance>)`);
  }
  const devicePath = await devicePathForAddress(address, { query });
  if (!devicePath) {
    throw new Error(`USB printer ${address} is not plugged in (no usbprint device with that id is present)`);
  }
  return writeRaw(devicePath, bytes, fs ? { fs } : {});
}
