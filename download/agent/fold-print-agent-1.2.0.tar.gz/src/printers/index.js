// Picks the backend for a job's printer record and turns OS queues into the
// `printers[]` list the heartbeat reports (so the POS can offer them in
// Settings → Receipts → "Add printer").
import * as network from './network.js';
import * as unix from './unix.js';
import * as usb from './usb.js';
import * as usbprint from './usbprint.js';
import * as windows from './windows.js';

const isWindows = process.platform === 'win32';

/**
 * Resolves the target for a job:
 *   transport NETWORK              → TCP 9100 at `address`
 *   transport AGENT, "network:…"   → TCP 9100
 *   transport AGENT, "usb:VID_…"   → Windows usbprint device interface, no queue
 *   transport AGENT, "usb:…"       → direct USB via libusb (bypasses CUPS entirely)
 *   transport AGENT, "system:…"    → OS queue
 *   transport AGENT, plain name    → OS queue
 * Anything else (Star WebPRNT / CloudPRNT) is not for the agent.
 */
export function resolveTarget(printer) {
  const transport = String(printer?.transport || '').toUpperCase();
  const address = String(printer?.address || '').trim();
  if (transport === 'NETWORK') {
    if (!address) throw new Error(`Printer "${printer?.name}" has no network address`);
    return { kind: 'network', address };
  }
  if (transport === 'AGENT') {
    if (!address) throw new Error(`Printer "${printer?.name}" has no queue name`);
    if (/^network:/i.test(address)) return { kind: 'network', address };
    if (usbprint.isUsbPrintAddress(address)) return { kind: 'usbprint', address };
    if (/^usb:/i.test(address)) return { kind: 'usb', address };
    return { kind: 'system', queue: address.replace(/^system:/i, '') };
  }
  throw new Error(`Transport ${transport || '(none)'} is not handled by the print agent`);
}

/** Writes bytes to the printer (`copies` times). Returns a short status string. */
export async function print(printer, bytes, { copies = 1, title = 'Fold POS', backends = defaultBackends() } = {}) {
  const target = resolveTarget(printer);
  const n = Math.max(1, Math.min(10, copies | 0));
  let last = '';
  let queue = target.queue;
  for (let i = 0; i < n; i++) {
    if (target.kind === 'network') {
      const sent = await backends.network.sendRaw(target.address, bytes);
      last = `${sent} bytes → ${target.address}`;
    } else if (target.kind === 'usb') {
      last = await backends.usb.sendRaw(target.address, bytes, { title });
    } else if (target.kind === 'usbprint') {
      last = await backends.usbprint.sendRaw(target.address, bytes);
    } else {
      try {
        last = await backends.system.sendRaw(queue, bytes, { title });
      } catch (e) {
        // Only a "no such printer" failure is worth a second look, and only
        // once: list the queues and retry on the one the saved name plainly
        // means. The normal path never pays for a queue listing.
        if (queue !== target.queue || !isNoSuchPrinter(e)) throw e;
        const { name, queues } = await resolveQueueName(target.queue, backends.system);
        if (!name) throw new Error(`${e.message}. Printers on this computer: ${queues.map((q) => `"${q}"`).join(', ') || 'none found'}. Pick one in Fold POS › Settings › Receipts.`);
        queue = name;
        last = await backends.system.sendRaw(queue, bytes, { title });
      }
    }
  }
  return n > 1 ? `${last} (×${n})` : last;
}

/** Windows OpenPrinter ERROR_INVALID_PRINTER_NAME (1801). */
export function isNoSuchPrinter(err) {
  return /OpenPrinter failed \(1801\)/.test(String(err?.message ?? err));
}

/** Virtual queues no receipt, tag or label is ever meant for. */
const VIRTUAL_QUEUE = /pdf|xps|onenote|fax|send to|document writer/i;

/**
 * The saved queue name is often typed by hand ("Epson TM-T20II") while Windows
 * calls the queue "EPSON TM-T20II Receipt". Case-insensitive first, then the
 * one queue whose squashed name contains the saved one. Never a virtual queue
 * (Print to PDF…), never a name that came back garbled (U+FFFD), never a
 * guess between two. Returns { name, queues }: name is null when there is no
 * single answer; queues is what the computer has, for the error message.
 */
export async function resolveQueueName(wanted, system) {
  let listed = [];
  try {
    listed = (await system.listQueues?.()) || [];
  } catch {
    listed = [];
  }
  const queues = listed.map((q) => q.name).filter(Boolean);
  const usable = queues.filter((n) => !VIRTUAL_QUEUE.test(n) && !n.includes('\uFFFD'));
  const ci = usable.filter((n) => n.toLowerCase() === String(wanted).toLowerCase());
  if (ci.length === 1) return { name: ci[0], queues };
  const w = squash(wanted);
  const fuzzy = w.length >= 4 ? usable.filter((n) => squash(n).includes(w)) : [];
  return { name: fuzzy.length === 1 ? fuzzy[0] : null, queues };
}

/** Lower-case, alphanumerics only — "EPSON_TM-T20II" and "TM-T20II" should not be two printers. */
const squash = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');

/**
 * True when a USB device is the same physical printer as a queue the OS
 * already offers, judged on NAME. This is guesswork — a queue somebody renamed
 * "Front counter" matches nothing — so it is only the fallback. Prefer
 * `sameAsQueue`, which compares serial numbers and is exact.
 */
export function matchesQueue(productName, queueNames) {
  const p = squash(productName);
  if (p.length < 4) return false;
  return queueNames.some((q) => q.length >= 4 && (q === p || q.includes(p) || p.includes(q)));
}

/**
 * Is this USB device the printer behind one of these queues?
 *
 * CUPS writes a USB queue's device URI as `usb://EPSON/TM-T20II?serial=…`, and
 * that serial is the same string the USB bus reports. When both sides have one
 * it is a fact, not a guess: two printers of the same model on one counter are
 * told apart correctly, and a renamed queue still matches.
 *
 * Only when the queue has no serial — a network queue, an older CUPS, a driver
 * that omits it — do we fall back to comparing names.
 */
export function sameAsQueue(device, queues) {
  const serial = squash(device?.serial);
  if (serial) {
    for (const q of queues) {
      if (q.deviceSerial && squash(q.deviceSerial) === serial) return true;
    }
    // The device has a serial and no queue claimed it. If every queue reported
    // a serial, that settles it — this printer has no queue. Saying so beats a
    // name that happens to look similar.
    if (queues.length && queues.every((q) => q.deviceSerial)) return false;
  }
  return matchesQueue(device?.product, queues.map((q) => squash(q.name)));
}

/**
 * The `printers[]` the heartbeat reports: OS queues first, then USB devices
 * the OS never enumerated, then manually configured LAN printers.
 * `usbDevices` can be passed in to reuse a scan the caller already did.
 */
export async function discoverPrinters({ manual = [], backends = defaultBackends(), usbDevices = null } = {}) {
  const queues = await backends.system.listQueues();
  const seen = new Set();
  const out = [];
  for (const q of queues) {
    if (seen.has(q.name)) continue;
    seen.add(q.name);
    out.push({ name: q.name, address: `system:${q.name}`, kind: 'system' });
  }

  // USB next: a device CUPS can already see is dropped, because a queue the
  // operator also sees in System Settings is the less confusing of the two.
  // Serial numbers decide it where both sides have one; names only otherwise.
  let usbList = usbDevices;
  if (!usbList) {
    try {
      usbList = await backends.usb.listDevices();
    } catch {
      usbList = [];
    }
  }
  for (const d of usbList || []) {
    if (!d?.address || seen.has(d.address)) continue;
    if (sameAsQueue(d, queues)) continue;
    seen.add(d.address);
    out.push({ name: d.name, address: d.address, kind: 'usb' });
  }

  // Windows: printers the usbprint class driver holds — plugged in, whether
  // or not anybody "added" them. They print straight through the device
  // interface. One that already has a queue by the same name is left to the
  // queue, which is the one the owner can see in Windows Settings.
  let direct = [];
  try {
    direct = await backends.usbprint.listDevices();
  } catch {
    direct = [];
  }
  for (const d of direct) {
    if (!d?.address || seen.has(d.address)) continue;
    if (matchesQueue(d.name, queues.map((q) => squash(q.name)))) continue;
    seen.add(d.address);
    out.push({ name: d.name, address: d.address, kind: 'usb' });
  }

  for (const m of manual) {
    if (!m?.address) continue;
    const address = /^network:/i.test(m.address) ? m.address : `network:${m.address}`;
    if (seen.has(address)) continue;
    seen.add(address);
    out.push({ name: m.name || m.address, address, kind: 'network' });
  }
  return out.slice(0, 50);
}

export function defaultBackends() {
  return { network, system: isWindows ? windows : unix, usb, usbprint };
}

/** Whether the optional USB module loaded, why not, and what is on the bus. For the status page. */
export async function usbStatus({ backends = defaultBackends() } = {}) {
  try {
    return await backends.usb.diagnose();
  } catch (e) {
    return { loaded: false, reason: `USB check failed: ${e.message}`, devices: [] };
  }
}
