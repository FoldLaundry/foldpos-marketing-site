// Windows: enumerate USB printers bound to the in-box `usbprint.sys` class
// driver by reading the registry directly with `reg.exe query`, no
// PowerShell and no native module.
//
// This is a cheaper, no-P/Invoke alternative to the SetupAPI enumeration in
// usbprint.js: the exact same device-interface GUID
// (GUID_DEVINTERFACE_USBPRINT, {28d78fad-5a12-11d1-ae5b-0000f803a8c2}) shows
// up as a tree of registry keys under
//   HKLM\SYSTEM\CurrentControlSet\Control\DeviceClasses\{28d78fad-...}
// with one subkey per device interface the class driver has ever created,
// named like
//   ##?#USB#VID_1504&PID_0059#6&2c3f1a2b&0&1#{28d78fad-...}
// The `##?#` is the registry's spelling of the `\\?\` device-path prefix
// CreateFile expects, so the device interface path a print job would open
// is that name with `##?#` swapped for `\\?\`.
//
// A device interface key stays in the registry after the printer is
// unplugged (Windows doesn't delete driver state on unplug), so presence
// has to be read separately: each device key has a `#` subkey, and that
// subkey gets its own `Control` subkey only while the device is currently
// linked in by PnP (Control\Linked = 1). No `#\Control` key at all means
// the printer isn't plugged in right now.
//
// The friendly product name isn't on the DeviceClasses side at all — it
// lives on the device's Enum node, either directly
// (HKLM\...\Enum\USB\VID_xxxx&PID_yyyy\<instance>\FriendlyName) or, for
// printers that got their own USBPRINT-class enum entry, one level over
// (HKLM\...\Enum\USBPRINT\<VendorProduct>\<instance>\FriendlyName), linked
// back to the USB node by ParentIdPrefix. Proven against a real device tree
// (Bixolon SRP-275III) on a Windows 11 PC on Sep 21 2026.
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileP = promisify(execFile);

/** GUID_DEVINTERFACE_USBPRINT — same GUID usbprint.js enumerates via SetupAPI. */
export const USBPRINT_INTERFACE_GUID = '28d78fad-5a12-11d1-ae5b-0000f803a8c2';

export const DEVICE_CLASSES_KEY = `HKLM\\SYSTEM\\CurrentControlSet\\Control\\DeviceClasses\\{${USBPRINT_INTERFACE_GUID}}`;
export const ENUM_USB_KEY = 'HKLM\\SYSTEM\\CurrentControlSet\\Enum\\USB';
export const ENUM_USBPRINT_KEY = 'HKLM\\SYSTEM\\CurrentControlSet\\Enum\\USBPRINT';

/** USB vendors whose printers are receipt/tag printers often enough to name from the VID alone. Same map as usbprint.js / usb.js. */
export const PRINTER_VENDORS = new Map([
  ['04b8', 'Epson'],
  ['0519', 'Star'],
  ['1504', 'Bixolon'],
  ['1d90', 'Citizen'],
  ['154f', 'SNBC'],
  ['0416', 'Zijiang'],
  ['0dd4', 'Custom'],
  ['0a5f', 'Zebra'],
]);

// The class driver's own generic description for the USB node — not a real
// product name, so it's never used as (or as a fallback for) a printer name.
const GENERIC_DEVICE_DESC = 'USB Printing Support';

const REPLACEMENT_CHAR = '�';

// -------------------------------------------------------------- reg query

/**
 * Default `query`: runs `reg.exe query "<keyPath>" [/s]` and returns raw
 * stdout. Injectable so tests (and non-Windows hosts) never shell out.
 */
async function regQuery(keyPath, { s = false } = {}) {
  const args = ['query', keyPath];
  if (s) args.push('/s');
  const { stdout } = await execFileP('reg.exe', args, {
    windowsHide: true,
    timeout: 15_000,
    maxBuffer: 16 * 1024 * 1024,
  });
  return stdout;
}

/**
 * Parses `reg query ... /s` output into an ordered list of
 * `{ key, values }`, where `key` is a full key path line and `values` is a
 * `{ [name]: data }` map of that key's `REG_*` values.
 *
 * reg.exe's text format: each key is printed on its own unindented line;
 * each of its values follows on an indented line shaped like
 * `    Name    REG_SZ    Data` (reg.exe pads with runs of spaces, not a
 * fixed column, so this splits on any run of 2+ spaces/tabs). Blank lines
 * separate keys but carry no meaning otherwise. A key with no values is
 * still recorded, with an empty `values` object.
 */
export function parseRegQuery(text) {
  const entries = [];
  if (!text) return entries;
  let current = null;
  for (const raw of String(text).split(/\r?\n/)) {
    if (raw.trim() === '') continue;
    if (/^\s/.test(raw)) {
      // Indented -> a value line of the current key. Ignored if malformed
      // or if it precedes any key line (shouldn't happen, but be lenient).
      if (!current) continue;
      const m = raw.match(/^\s+(\S.*?)\s{2,}(REG_[A-Z_0-9]+)\s{2,}([\s\S]*)$/);
      if (m) current.values[m[1]] = m[3];
      continue;
    }
    const line = raw.trim();
    if (/^ERROR:/i.test(line)) continue; // "unable to find the specified registry key"
    current = { key: line, values: {} };
    entries.push(current);
  }
  return entries;
}

/** Direct children of `parentKey` at `depth` path segments below it (default 1), as `{ name, key, values }`. */
function childrenOf(entries, parentKey, depth = 1) {
  const prefix = parentKey.toLowerCase() + '\\';
  const out = [];
  for (const e of entries) {
    if (e.key.length <= parentKey.length) continue;
    if (!e.key.toLowerCase().startsWith(prefix)) continue;
    const rel = e.key.slice(parentKey.length + 1);
    const parts = rel.split('\\');
    if (parts.length === depth) out.push({ name: parts[parts.length - 1], key: e.key, values: e.values });
  }
  return out;
}

/** Exact-match lookup of one key's values by full path (registry paths are case-insensitive). */
function findKey(entries, keyPath) {
  const target = keyPath.toLowerCase();
  return entries.find((e) => e.key.toLowerCase() === target) ?? null;
}

// -------------------------------------------------------------- device paths

/** `##?#USB#VID_xxxx&PID_yyyy#<instance>#{guid}` (a DeviceClasses subkey name) -> `\\?\USB#VID_xxxx&PID_yyyy#<instance>#{guid}` (an openable device interface path). */
export function devicePathFromKeyName(keyName) {
  return String(keyName).replace(/^##\?#/, '\\\\?\\');
}

/** Pulls `{ vendorId, productId, instance }` (ids lower-case hex) out of a `\\?\USB#VID_xxxx&PID_yyyy#<instance>#...` device interface path. Returns null if it doesn't match. */
export function parseDevicePath(devicePath) {
  const m = String(devicePath).match(/USB#VID_([0-9a-fA-F]{4})&PID_([0-9a-fA-F]{4})#([^#]+)#/);
  if (!m) return null;
  return { vendorId: m[1].toLowerCase(), productId: m[2].toLowerCase(), instance: m[3] };
}

// -------------------------------------------------------------- naming

function isUsable(name) {
  return typeof name === 'string' && name.length > 0 && !name.includes(REPLACEMENT_CHAR);
}

/**
 * Resolves the human name for one present device, given:
 *  - vidPid: 'VID_1504&PID_0059' (upper-case, as Windows writes it)
 *  - instance: the USB instance id, e.g. '6&2c3f1a2b&0&1'
 *  - usbEntries / usbprintEntries: parsed `reg query /s` output of
 *    Enum\USB and Enum\USBPRINT respectively
 */
function resolveName(vidPid, instance, vendorId, productId, usbEntries, usbprintEntries) {
  const usbNodeKey = `${ENUM_USB_KEY}\\${vidPid}\\${instance}`;
  const usbNode = findKey(usbEntries, usbNodeKey);
  const parentIdPrefix = usbNode?.values.ParentIdPrefix;

  // 1) A USBPRINT enum node whose own instance id starts with the USB
  //    node's ParentIdPrefix (Windows' way of linking the two enum trees
  //    for the same physical device).
  if (parentIdPrefix) {
    for (const vendorProduct of childrenOf(usbprintEntries, ENUM_USBPRINT_KEY, 1)) {
      for (const inst of childrenOf(usbprintEntries, vendorProduct.key, 1)) {
        if (inst.name.startsWith(parentIdPrefix)) {
          const name = inst.values.FriendlyName ?? inst.values.DeviceDesc;
          if (isUsable(name)) return name;
        }
      }
    }
  }

  // 2) The USB node's own name — but not the class driver's generic
  //    "USB Printing Support" description.
  if (usbNode) {
    if (isUsable(usbNode.values.FriendlyName)) return usbNode.values.FriendlyName;
    const desc = usbNode.values.DeviceDesc;
    if (isUsable(desc) && desc !== GENERIC_DEVICE_DESC) return desc;
  }

  // 3) Generic "<Vendor> printer VID:PID" fallback.
  const vendor = PRINTER_VENDORS.get(vendorId);
  if (vendor) return `${vendor} printer ${vendorId}:${productId}`;
  return `USB printer ${vendorId}:${productId}`;
}

// -------------------------------------------------------------- the module

/**
 * Lists present USB printers bound to the usbprint.sys class driver, read
 * straight out of the registry. Never throws: returns `[]` on any failure,
 * and on any platform other than win32 unless `query` is injected (so tests
 * can run this on Linux/CI).
 *
 * @param {{ query?: (keyPath: string, opts?: { s?: boolean }) => Promise<string> }} [options]
 * @returns {Promise<Array<{ name: string, devicePath: string, vendorId: string, productId: string, instance: string, address: string }>>}
 */
export async function listDevices({ query } = {}) {
  const q = query ?? (process.platform === 'win32' ? regQuery : null);
  if (!q) return [];

  // The class tree first: it is small (one key per printer ever plugged
  // in) and says which ones are here now. Enum\USB is NOT walked whole —
  // every hub, mouse and phone lives there — only the nodes of the present
  // printers are read, plus Enum\USBPRINT, which holds printers alone.
  let deviceEntries;
  try {
    deviceEntries = parseRegQuery(await q(DEVICE_CLASSES_KEY, { s: true }));
  } catch {
    return [];
  }

  const present = [];
  for (const dev of childrenOf(deviceEntries, DEVICE_CLASSES_KEY, 1)) {
    const devicePath = devicePathFromKeyName(dev.name);
    const ids = parseDevicePath(devicePath);
    if (!ids) continue;
    // Presence: only while <devkey>\#\Control exists. If it exists but
    // Linked can't be read, be optimistic and treat it as present rather
    // than hide a printer over a value we failed to parse.
    const control = findKey(deviceEntries, `${dev.key}\\#\\Control`);
    if (!control) continue; // no Control key at all -> unplugged
    const linked = control.values.Linked;
    if (linked !== undefined && !/^0x0*1$/i.test(linked.trim())) continue;
    present.push({ devicePath, ...ids });
  }
  if (!present.length) return [];

  let usbprintEntries = [];
  try {
    usbprintEntries = parseRegQuery(await q(ENUM_USBPRINT_KEY, { s: true }));
  } catch {
    usbprintEntries = [];
  }

  const results = [];
  for (const { devicePath, vendorId, productId, instance } of present) {
    try {
      const vidPid = `VID_${vendorId.toUpperCase()}&PID_${productId.toUpperCase()}`;
      let usbEntries = [];
      try {
        usbEntries = parseRegQuery(await q(`${ENUM_USB_KEY}\\${vidPid}\\${instance}`, { s: false }));
      } catch {
        usbEntries = [];
      }
      const name = resolveName(vidPid, instance, vendorId, productId, usbEntries, usbprintEntries);
      const address = `usb:${vidPid}&${instance}`;
      results.push({ name, devicePath, vendorId, productId, instance, address });
    } catch {
      // One malformed device key shouldn't take down the whole listing.
      continue;
    }
  }
  return results;
}

/** `usb:VID_1504&PID_0059&<instance>` → the present device's interface path, or null. */
export async function devicePathForAddress(address, { query } = {}) {
  const m = /^usb:VID_([0-9a-f]{4})&PID_([0-9a-f]{4})&(.+)$/i.exec(String(address ?? '').trim());
  if (!m) return null;
  const [, vid, pid, instance] = m;
  const devices = await listDevices({ query });
  const hit =
    devices.find((d) => d.vendorId === vid.toLowerCase() && d.productId === pid.toLowerCase() && d.instance === instance) ??
    // Instance ids without a serial number change with the port; a lone
    // printer of that model is still the one meant.
    (() => {
      const same = devices.filter((d) => d.vendorId === vid.toLowerCase() && d.productId === pid.toLowerCase());
      return same.length === 1 ? same[0] : null;
    })();
  return hit?.devicePath ?? null;
}
