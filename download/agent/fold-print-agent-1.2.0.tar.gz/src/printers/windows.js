// Windows: the print spooler's RAW datatype through winspool.drv. There is no
// `lp -o raw` on Windows, so a small PowerShell script P/Invokes
// OpenPrinter / StartDocPrinter(RAW) / WritePrinter — the standard
// "RawPrinterHelper" pattern Microsoft documents. Works for USB, Bluetooth
// and network queues that Windows already knows about; no driver settings
// are touched. Discovery is `Get-Printer`.
import { execFile } from 'node:child_process';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';

const execFileP = promisify(execFile);

export const RAW_PRINT_PS1 = String.raw`
param([Parameter(Mandatory=$true)][string]$Printer, [Parameter(Mandatory=$true)][string]$Path, [string]$Title = "Fold POS")
$ErrorActionPreference = "Stop"
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class FoldRawPrinter {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct DOCINFOW { [MarshalAs(UnmanagedType.LPWStr)] public string pDocName; [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile; [MarshalAs(UnmanagedType.LPWStr)] public string pDataType; }
  [DllImport("winspool.drv", EntryPoint="OpenPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern bool OpenPrinter(string name, out IntPtr h, IntPtr pd);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool ClosePrinter(IntPtr h);
  [DllImport("winspool.drv", EntryPoint="StartDocPrinterW", SetLastError=true, CharSet=CharSet.Unicode)] public static extern int StartDocPrinter(IntPtr h, int level, ref DOCINFOW di);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndDocPrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool StartPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool EndPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError=true)] public static extern bool WritePrinter(IntPtr h, byte[] buf, int len, out int written);
  public static int Send(string printer, byte[] bytes, string title) {
    IntPtr h;
    if (!OpenPrinter(printer, out h, IntPtr.Zero)) throw new Exception("OpenPrinter failed (" + Marshal.GetLastWin32Error() + ") for '" + printer + "'");
    try {
      DOCINFOW di = new DOCINFOW(); di.pDocName = title; di.pDataType = "RAW";
      if (StartDocPrinter(h, 1, ref di) == 0) throw new Exception("StartDocPrinter failed (" + Marshal.GetLastWin32Error() + ")");
      try {
        if (!StartPagePrinter(h)) throw new Exception("StartPagePrinter failed");
        int written;
        if (!WritePrinter(h, bytes, bytes.Length, out written)) throw new Exception("WritePrinter failed (" + Marshal.GetLastWin32Error() + ")");
        EndPagePrinter(h);
        return written;
      } finally { EndDocPrinter(h); }
    } finally { ClosePrinter(h); }
  }
}
"@
$bytes = [System.IO.File]::ReadAllBytes($Path)
$written = [FoldRawPrinter]::Send($Printer, $bytes, $Title)
Write-Output "written=$written"
`;

// UTF-8 out: Windows PowerShell 5.1 otherwise writes redirected output in
// the OEM code page, and "Impresión" arrives as "Impresi\uFFFDn".
export const LIST_PRINTERS_PS1 = '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Printer | Select-Object Name,DriverName,PortName,PrinterStatus | ConvertTo-Json -Compress';

function powershell(args, opts = {}) {
  return execFileP('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', ...args], {
    timeout: 30_000,
    windowsHide: true,
    ...opts,
  });
}

export async function listQueues() {
  try {
    const { stdout } = await powershell(['-Command', LIST_PRINTERS_PS1]);
    return parseGetPrinter(stdout);
  } catch {
    return [];
  }
}

/** Output of Get-Printer | ConvertTo-Json (object or array) → [{ name, status }] */
export function parseGetPrinter(stdout) {
  const text = String(stdout).trim();
  if (!text) return [];
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return [];
  }
  const list = Array.isArray(parsed) ? parsed : [parsed];
  return list
    .filter((p) => p && p.Name)
    .map((p) => ({ name: String(p.Name), status: String(p.PrinterStatus ?? ''), port: p.PortName, driver: p.DriverName }));
}

let scriptPathCache = null;
async function scriptPath() {
  if (scriptPathCache) return scriptPathCache;
  const dir = path.join(os.tmpdir(), 'fold-print-agent');
  await fs.mkdir(dir, { recursive: true });
  const p = path.join(dir, 'rawprint.ps1');
  await fs.writeFile(p, RAW_PRINT_PS1, 'utf8');
  scriptPathCache = p;
  return p;
}

/**
 * PowerShell wraps a .NET exception over several lines; the first is only
 * 'Exception calling "Send" with "3" argument(s):' — the cause is after it.
 * Pull out our own "… failed (NNNN) …" text and name the common Win32 codes.
 */
const WIN32_HINTS = {
  1801: 'no printer with that name on this computer',
  5: 'access denied',
  1722: 'print spooler not running',
  1797: 'printer driver unknown',
};
export function windowsErrorMessage(stderr) {
  // PowerShell wraps long lines, so a long printer name can span two; join
  // them before looking for our own "… failed (NNNN) for '…'" text.
  const text = String(stderr).replace(/\r?\n\s*/g, ' ');
  const ours = text.match(/(OpenPrinter|StartDocPrinter|WritePrinter|StartPagePrinter) failed(?: \((\d+)\))?(?: for '[^']*')?/);
  if (ours) {
    const code = Number(ours[2]);
    return WIN32_HINTS[code] ? `${ours[0]} — ${WIN32_HINTS[code]}` : ours[0];
  }
  return text.replace(/\s+/g, ' ').trim().slice(0, 300);
}

export async function sendRaw(printerName, bytes, { title = 'Fold POS' } = {}) {
  const name = String(printerName || '').replace(/^system:/i, '').trim();
  if (!name) throw new Error('Printer name is empty');
  const tmp = path.join(os.tmpdir(), `fold-print-${process.pid}-${Date.now()}.bin`);
  await fs.writeFile(tmp, bytes);
  try {
    const { stdout } = await powershell(['-File', await scriptPath(), '-Printer', name, '-Path', tmp, '-Title', title]);
    return stdout.trim();
  } catch (e) {
    const msg = windowsErrorMessage(e.stderr || e.message || '');
    throw new Error(`Windows raw print to "${name}" failed: ${msg}`);
  } finally {
    fs.unlink(tmp).catch(() => {});
  }
}
