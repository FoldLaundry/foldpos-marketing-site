// Raw TCP ("JetDirect", port 9100) — Epson, Star, Bixolon, Zebra all speak it.
import net from 'node:net';

/** Parses "host", "host:port", "network:host:port" → { host, port }. */
export function parseNetworkAddress(address) {
  let s = String(address || '').trim().replace(/^network:/i, '');
  if (!s) throw new Error('Network printer has no address');
  let host = s;
  let port = 9100;
  const m = /^\[?([^\]]+?)\]?:(\d{2,5})$/.exec(s);
  if (m) {
    host = m[1];
    port = Number(m[2]);
  }
  return { host, port };
}

/**
 * Writes `bytes` to host:port and waits for the socket to drain and close.
 * Resolves with the byte count; rejects on connect/write errors or timeout.
 */
export function sendRaw(address, bytes, { timeoutMs = 15_000 } = {}) {
  const { host, port } = parseNetworkAddress(address);
  return new Promise((resolve, reject) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (err) => {
      if (done) return;
      done = true;
      socket.destroy();
      err ? reject(err) : resolve(bytes.length);
    };
    socket.setTimeout(timeoutMs, () => finish(new Error(`Printer ${host}:${port} timed out`)));
    socket.once('error', (e) => finish(new Error(`Printer ${host}:${port}: ${e.message}`)));
    socket.connect(port, host, () => {
      socket.end(bytes, () => {
        // Give the printer a moment to pull the buffer before we hang up.
        setTimeout(() => finish(), 150);
      });
    });
  });
}
