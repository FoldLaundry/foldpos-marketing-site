// Windows: a USB printer with NO queue, printed to directly — via Node's own
// fs, no PowerShell and no native module.
//
// usbprint.js's header claimed "a .NET FileStream refuses device paths;
// Node's fs will not open them either; kernel32 does" and shelled out to
// PowerShell to P/Invoke CreateFile/WriteFile. That claim was WRONG. Proven
// on a real Windows 11 PC, standard user, no driver or queue, Sep 21 2026:
//
//   fs.openSync('\\\\?\\USB#VID_1504&PID_0059#<instance>#{28d78fad-…}', 'w')
//
// succeeds — Node's fs maps straight to CreateFileW — and fs.writeSync(fd,
// buffer) sends the bytes to the printer, fs.closeSync(fd) finishes the job.
// This module supersedes usbprint.js: same device interface path (the
// usbprint class driver's \\?\USB#VID_…#{28d78fad-5a12-11d1-ae5b-0000f803a8c2}
// path), but written with fs alone — no temp script, no child process.
import nodeFs from 'node:fs';

/** A Windows device / "verbatim" path: \\?\... or \\.\... */
const DEVICE_PATH_RE = /^\\\\[?.]\\/;

const ERROR_HINTS = {
  ENOENT: 'the printer is unplugged or on another port',
  EACCES: 'access denied — another program (a print queue?) holds the printer open',
  EPERM: 'access denied — another program (a print queue?) holds the printer open',
  EBUSY: 'the printer is busy with another program',
};

/** Maps a Node fs error (ENOENT/EACCES/EPERM/EBUSY/…) to a plain-English hint. */
export function usbWriteErrorMessage(err) {
  const hint = ERROR_HINTS[err?.code];
  return hint ?? (err?.message ?? String(err));
}

/** Opens `devicePath` for writing. The open flag lives here, and only here. */
export function openForWrite(devicePath, fsImpl = nodeFs) {
  return fsImpl.openSync(devicePath, 'w');
}

/**
 * Writes `bytes` to a Windows usbprint device interface path in chunks,
 * looping over writeSync (which can return short writes) until every byte
 * is sent. Always closes the fd. Resolves with a status string such as
 * `written=1234 bytes → \\?\USB#VID_1504&PID_0059#…` — the print agent shows
 * this on its status page.
 */
export async function sendRaw(devicePath, bytes, { fs: fsImpl = nodeFs, chunkSize = 4096 } = {}) {
  const path = String(devicePath ?? '');
  if (!DEVICE_PATH_RE.test(path)) {
    throw new Error(`"${path}" is not a Windows device path`);
  }
  if (!(bytes instanceof Uint8Array) || bytes.length < 1) {
    throw new Error('Bytes to print must be a non-empty Buffer');
  }

  let fd;
  try {
    fd = openForWrite(path, fsImpl);
  } catch (e) {
    throw new Error(`USB print to "${path}" failed: ${usbWriteErrorMessage(e)}`);
  }

  try {
    let written = 0;
    while (written < bytes.length) {
      const len = Math.min(chunkSize, bytes.length - written);
      const n = fsImpl.writeSync(fd, bytes, written, len);
      // A driver that accepts nothing would otherwise spin here forever.
      if (!(n > 0)) throw new Error('the printer accepted no data (write returned 0 bytes)');
      written += n;
    }
    return `written=${written} bytes → ${path}`;
  } catch (e) {
    throw new Error(`USB print to "${path}" failed: ${usbWriteErrorMessage(e)}`);
  } finally {
    fsImpl.closeSync(fd);
  }
}
