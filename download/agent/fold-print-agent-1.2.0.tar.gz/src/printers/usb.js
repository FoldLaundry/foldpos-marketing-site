// Direct USB, for printers the OS refuses to enumerate.
//
// Most Epson TM models present a *vendor class* interface (bInterfaceClass =
// 255) instead of the printer class (7). CUPS's usb backend only walks
// printer-class interfaces, so such a printer never shows up in `lpstat -p`,
// no queue can exist for it, and the shop is simply told "the printer isn't
// there". Verified on a TM-T88V: class 255, subclass 255, protocol 2.
//
// Vendor class also means no kernel driver has claimed the interface — so we
// can open it ourselves and write the ESC/POS bytes to its bulk OUT endpoint,
// which is exactly what the OS would have done. Proven on that same printer:
// a full receipt and two garment tags came out.
//
// The native `usb` module is an *optional* dependency: the agent had zero
// dependencies before this file and must still start, print over CUPS and
// print over TCP when the module is missing or fails to build.
//
// node-usb v3 dropped the old libusb-shaped API (getDeviceList, endpoint
// .transfer) and exposes WebUSB instead, which is what this file uses:
// `usb.getDevices()`, `device.open()`, `claimInterface()`, `transferOut()`.
// Everything here is promise-based for that reason.

/** Vendors whose USB devices are thermal receipt/tag printers often enough to list unconditionally. */
export const THERMAL_PRINTER_VENDORS = new Map([
  [0x04b8, 'Epson'],
  [0x0519, 'Star'],
  [0x1504, 'Bixolon'],
  [0x1d90, 'Citizen'],
  [0x154f, 'SNBC'],
  [0x0416, 'Zijiang'],
  [0x0dd4, 'Custom'],
]);

const PRINTER_INTERFACE_CLASS = 7;

const hex4 = (n) => Number(n ?? 0).toString(16).toLowerCase().padStart(4, '0');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------- the module

let loaded = null; // memoised { lib, reason } — the import is attempted once

/**
 * Loads the optional native module. Never throws: on failure it returns
 * `{ lib: null, reason }` and the reason is what the status page shows, so a
 * store is never left guessing why its printer is missing.
 */
export async function loadUsbLib() {
  if (loaded) return loaded;
  try {
    const mod = await import('usb');
    const lib = mod.usb ?? mod.default?.usb ?? mod.default ?? mod;
    if (typeof lib.getDevices !== 'function') {
      throw new Error('the "usb" module does not expose getDevices() — expected v3 or newer');
    }
    loaded = { lib, reason: null };
  } catch (e) {
    loaded = {
      lib: null,
      reason:
        'USB support is off: the optional "usb" module is not installed ' +
        `(${firstLine(e)}). Run "npm install usb" in the print-agent folder to turn it on.`,
    };
  }
  return loaded;
}

/** Test seam: drop a fake module in, or `null` to force the "not installed" path. */
export function __setUsbLib(lib, reason = 'USB support is off (test)') {
  loaded = lib ? { lib, reason: null } : { lib: null, reason };
}

/** Test seam: forget the memoised import so the next call tries again. */
export function __resetUsbLib() {
  loaded = null;
}

// --------------------------------------------------------------- addressing

/**
 * `usb:<vid>:<pid>[:<serial>]` → { vendorId, productId, serial }.
 * Hex is normalised to four lower-case digits so an address written by hand
 * matches one we discovered. Two identical printers on one counter is normal,
 * and the serial is the only thing that tells them apart.
 */
export function parseUsbAddress(address) {
  const s = String(address ?? '').trim();
  const m = /^usb:([0-9a-f]{1,4}):([0-9a-f]{1,4})(?::([\w .:+/-]{1,64}))?$/i.exec(s);
  if (!m) {
    throw new Error(
      `"${s}" is not a USB printer address (expected usb:04b8:0202 or usb:04b8:0202:SERIAL)`,
    );
  }
  return {
    vendorId: parseInt(m[1], 16),
    productId: parseInt(m[2], 16),
    serial: m[3] ? m[3].trim() : null,
  };
}

export function formatUsbAddress(vendorId, productId, serial) {
  const base = `usb:${hex4(vendorId)}:${hex4(productId)}`;
  return serial ? `${base}:${serial}` : base;
}

// --------------------------------------------------------------- discovery

/** Every alternate setting across every configuration the device reports. */
function alternates(device) {
  const configs = device?.configurations?.length
    ? device.configurations
    : device?.configuration
      ? [device.configuration]
      : [];
  const out = [];
  for (const cfg of configs) {
    for (const iface of cfg?.interfaces ?? []) {
      const alts = iface?.alternates?.length ? iface.alternates : [iface?.alternate];
      for (const alt of alts) if (alt) out.push({ interfaceNumber: iface.interfaceNumber, alt });
    }
  }
  return out;
}

/** A device is interesting if it is a known printer vendor or advertises a printer-class interface. */
export function isPrinterLike(device) {
  if (THERMAL_PRINTER_VENDORS.has(device?.vendorId)) return true;
  return alternates(device).some(({ alt }) => alt?.interfaceClass === PRINTER_INTERFACE_CLASS);
}

/**
 * Devices on the bus that look like printers.
 *
 * WebUSB hands us the product and serial strings without opening the device,
 * so discovery never disturbs a printer that is mid-job.
 * Never throws — a device we can see but cannot print to is reported with
 * `error` rather than dropped, because that is the diagnosis the shop needs.
 */
export async function listDevices({ lib = null } = {}) {
  const usb = lib ?? (await loadUsbLib()).lib;
  if (!usb) return [];
  let devices = [];
  try {
    devices = (await usb.getDevices()) || [];
  } catch {
    return [];
  }
  const out = [];
  for (const device of devices) {
    let printerLike = false;
    try {
      printerLike = isPrinterLike(device);
    } catch {
      printerLike = false;
    }
    if (!printerLike) continue;
    const vendorId = device.vendorId ?? 0;
    const productId = device.productId ?? 0;
    const product = cleanString(device.productName);
    const serial = cleanString(device.serialNumber);
    let endpointError = null;
    try {
      // No bulk OUT endpoint means we can list it but never print to it. Say
      // so here rather than at the counter, mid-order.
      if (!pickEndpoint(device)) {
        endpointError = 'no bulk OUT endpoint — this device may need its vendor driver';
      }
    } catch {
      endpointError = 'could not read this device’s endpoints';
    }
    out.push({
      name: product || `USB printer ${hex4(vendorId)}:${hex4(productId)}`,
      address: formatUsbAddress(vendorId, productId, serial),
      kind: 'usb',
      vendorId: hex4(vendorId),
      productId: hex4(productId),
      serial: serial || null,
      product: product || null,
      error: endpointError,
    });
  }
  return out;
}

const cleanString = (v) => {
  const s = String(v ?? '').replace(/\0/g, '').trim();
  return s || null;
};

/** What the status page shows: did the module load, why not, and what is on the bus. */
export async function diagnose({ lib = null } = {}) {
  const state = lib ? { lib, reason: null } : await loadUsbLib();
  if (!state.lib) return { loaded: false, reason: state.reason, devices: [] };
  return { loaded: true, reason: null, devices: await listDevices({ lib: state.lib }) };
}

// ----------------------------------------------------------------- printing

/**
 * The interface and bulk endpoints to print on: the lowest-numbered interface
 * that has a bulk OUT. Null means the device cannot be printed to this way at
 * all. `inEndpointNumber` is null on printers that offer no bulk IN — those
 * can be printed to but never asked how they are.
 */
export function pickEndpoint(device) {
  const cfg = device?.configuration ?? device?.configurations?.[0];
  const ifaces = [...(cfg?.interfaces ?? [])].sort(
    (a, b) => (a?.interfaceNumber ?? 0) - (b?.interfaceNumber ?? 0),
  );
  for (const iface of ifaces) {
    const alt = iface?.alternate ?? iface?.alternates?.[0];
    const eps = alt?.endpoints ?? [];
    const ep = eps.find((e) => e?.direction === 'out' && e?.type === 'bulk');
    if (ep) {
      const inEp = eps.find((e) => e?.direction === 'in' && e?.type === 'bulk');
      return {
        interfaceNumber: iface.interfaceNumber ?? 0,
        endpointNumber: ep.endpointNumber,
        inEndpointNumber: inEp ? inEp.endpointNumber : null,
        packetSize: Number(ep.packetSize) || 64,
        configurationValue: cfg?.configurationValue ?? 1,
      };
    }
  }
  return null;
}

// ------------------------------------------------------------ printer status
//
// ESC/POS real-time status: DLE EOT n. The printer answers with a single byte
// even while it is busy, which is the only way to learn that it is out of
// paper or that someone left the cover open. Without this the agent is
// write-only and reports a receipt as printed when none came out — the exact
// blind spot `lp` has, and the one a store notices at the worst moment.
//
// Every reply has bit0 = 0, bit1 = 1 and bit4 = 1. Anything else is not a
// status byte (some printers answer nothing at all), and we say "unknown"
// rather than invent an answer.

const DLE_EOT = (n) => Buffer.from([0x10, 0x04, n]);
const STATUS_FIXED_MASK = 0b1001_0011;
const STATUS_FIXED_BITS = 0b0001_0010;

export function isStatusByte(b) {
  return Number.isInteger(b) && (b & STATUS_FIXED_MASK) === STATUS_FIXED_BITS;
}

/** DLE EOT 2 — "offline cause". */
export function decodeOfflineStatus(b) {
  if (!isStatusByte(b)) return null;
  return {
    coverOpen: !!(b & 0x04),
    paperFedByButton: !!(b & 0x08),
    paperEnd: !!(b & 0x20),
    error: !!(b & 0x40),
  };
}

/** DLE EOT 4 — the paper roll sensors. */
export function decodePaperStatus(b) {
  if (!isStatusByte(b)) return null;
  return {
    // Both bits are set together on an Epson; either alone still means low.
    paperNearEnd: !!(b & 0x0c),
    paperOut: !!(b & 0x60),
  };
}

/**
 * Turns the two status bytes into one plain sentence, or null when everything
 * is fine. This is what a person reads, so it says the thing to go and do.
 */
export function describeStatus({ offline, paper }) {
  if (offline?.coverOpen) return 'the printer cover is open';
  if (paper?.paperOut || offline?.paperEnd) return 'the printer is out of paper';
  if (offline?.error) return 'the printer is reporting an error — check for a paper jam';
  if (paper?.paperNearEnd) return 'the paper roll is nearly empty';
  return null;
}

/**
 * The round trip itself, on a device that is already open and claimed.
 * Used both by `queryStatus` and by `sendRaw`'s pre-flight check, so a print
 * never pays for a second open.
 */
async function readStatus(device, picked, timeoutMs) {
  const ask = async (n) => {
    await withTimeout(device.transferOut(picked.endpointNumber, DLE_EOT(n)), timeoutMs);
    const res = await withTimeout(device.transferIn(picked.inEndpointNumber, 1), timeoutMs);
    const data = res?.data;
    if (!data) return null;
    // Either a DataView (WebUSB) or something byte-indexable.
    return typeof data.getUint8 === 'function' ? data.getUint8(0) : data[0];
  };
  let offline = null;
  let paper = null;
  try {
    offline = decodeOfflineStatus(await ask(2));
    paper = decodePaperStatus(await ask(4));
  } catch (e) {
    // A printer that ignores DLE EOT leaves us waiting. Not an error — most of
    // them answer, some do not, and printing must not depend on it.
    return { known: false, reason: firstLine(e) };
  }
  if (!offline && !paper) return { known: false, reason: 'the printer did not answer' };
  const message = describeStatus({ offline, paper });
  return { known: true, ok: message === null, message, offline, paper };
}

/**
 * Asks a USB printer how it is. Returns `{ known: false }` when the printer
 * does not answer — plenty do not, and a silent printer is not a broken one.
 * Never throws.
 */
export async function queryStatus(address, { lib = null, timeoutMs = 1500 } = {}) {
  let device = null;
  let claimed = null;
  let opened = false;
  try {
    const want = parseUsbAddress(address);
    const usb = lib ?? (await loadUsbLib()).lib;
    if (!usb) return { known: false, reason: 'USB support is off' };
    device = await findDevice(usb, want);
    if (!device) return { known: false, reason: 'printer not found' };

    await device.open();
    opened = true;
    if (!device.configuration) {
      await device.selectConfiguration(device.configurations?.[0]?.configurationValue ?? 1);
    }
    const picked = pickEndpoint(device);
    if (!picked || picked.inEndpointNumber == null) {
      return { known: false, reason: 'this printer does not report its status' };
    }
    await device.claimInterface(picked.interfaceNumber);
    claimed = picked.interfaceNumber;

    return await readStatus(device, picked, timeoutMs);
  } catch (e) {
    return { known: false, reason: firstLine(e) };
  } finally {
    if (claimed !== null) {
      try {
        await device.releaseInterface(claimed);
      } catch {
        /* gone */
      }
    }
    if (opened) {
      try {
        await device.close();
      } catch {
        /* gone */
      }
    }
  }
}

/**
 * Writes raw bytes to a USB printer.
 *
 * Thermal printers have a tiny buffer, so the stream goes out in packet-sized
 * chunks with a breath between them — one oversized write is the classic way
 * to get half a receipt. The interface is released and the device closed on
 * every path, including a throw: a leaked claim means the next print fails
 * and someone has to unplug the printer.
 *
 * Worth knowing: this is write-only. The printer does not tell us it is out of
 * paper, so a job that leaves here is reported as printed — the same blind
 * spot `lp` has.
 */
export async function sendRaw(
  address,
  bytes,
  { lib = null, timeoutMs = 15_000, pauseMs = 4, checkStatus = true } = {},
) {
  const want = parseUsbAddress(address);
  const usb = lib ?? (await loadUsbLib()).lib;
  if (!usb) {
    throw new Error((await loadUsbLib()).reason || 'USB support is not available on this computer');
  }

  const device = await findDevice(usb, want);
  if (!device) throw new Error(`No USB printer at ${address} — check it is plugged in and switched on`);

  const buf = Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes);
  let claimed = null;
  let opened = false;
  try {
    await device.open();
    opened = true;
    if (!device.configuration) {
      await device.selectConfiguration(device.configurations?.[0]?.configurationValue ?? 1);
    }
    const picked = pickEndpoint(device);
    if (!picked) {
      throw new Error(
        `USB printer at ${address} has no bulk OUT endpoint — it may need its vendor driver`,
      );
    }
    // Linux binds usblp to printer-class interfaces; without this the claim fails.
    if (process.platform === 'linux' && typeof device.detachKernelDriver === 'function') {
      try {
        await device.detachKernelDriver(picked.interfaceNumber);
      } catch {
        /* nothing was attached — the claim below will say if it mattered */
      }
    }
    await device.claimInterface(picked.interfaceNumber);
    claimed = picked.interfaceNumber;

    // Ask before writing. A printer with its cover open or no paper swallows
    // the bytes and the counter is told the receipt printed. One round trip
    // inside the claim we already hold, skipped entirely on printers that
    // cannot answer.
    if (checkStatus && picked.inEndpointNumber != null) {
      const status = await readStatus(device, picked, 1500);
      if (status.known && !status.ok) {
        throw new Error(`Nothing was sent — ${status.message}.`);
      }
    }

    const chunk = Math.max(8, picked.packetSize);
    for (let i = 0; i < buf.length; i += chunk) {
      await withTimeout(
        device.transferOut(picked.endpointNumber, buf.subarray(i, i + chunk)),
        timeoutMs,
      );
      if (pauseMs > 0 && i + chunk < buf.length) await sleep(pauseMs);
    }
    return `${buf.length} bytes → ${address}`;
  } catch (e) {
    throw new Error(friendlyUsbError(e, address));
  } finally {
    if (claimed !== null) {
      try {
        await device.releaseInterface(claimed);
      } catch {
        /* the device may already be gone */
      }
    }
    if (opened) {
      try {
        await device.close();
      } catch {
        /* already gone */
      }
    }
  }
}

async function findDevice(usb, want) {
  let devices = [];
  try {
    devices = (await usb.getDevices()) || [];
  } catch {
    return null;
  }
  const matches = devices.filter(
    (d) => d?.vendorId === want.vendorId && d?.productId === want.productId,
  );
  if (!want.serial) return matches[0] || null;
  const exact = matches.find((d) => cleanString(d.serialNumber) === want.serial);
  if (exact) return exact;
  // The address names a serial we cannot see. Printing to "one of them" when
  // two identical printers share a counter would put a receipt on the wrong
  // one, so only fall back when there is genuinely no ambiguity.
  return matches.length === 1 ? matches[0] : null;
}

function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`USB write timed out after ${ms}ms`)), ms);
    timer.unref?.();
    Promise.resolve(promise).then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      },
    );
  });
}

/** libusb codes mean nothing to a shop owner. Say what happened and what to do. */
export function friendlyUsbError(e, address = '') {
  const raw = firstLine(e);
  const at = address ? ` (${address})` : '';
  if (address && raw.includes(address)) return raw; // already ours, already plain
  if (/LIBUSB_ERROR_ACCESS|access denied|permission|EACCES|insufficient permissions/i.test(raw)) {
    if (process.platform === 'darwin') {
      return `macOS would not let Fold open this printer${at}. Quit any Epson/Star utility that has it open, remove its queue from System Settings → Printers, then unplug and replug the printer.`;
    }
    if (process.platform === 'win32') {
      return `Windows would not let Fold open this printer${at}. Its vendor driver has the device; use the printer's Windows queue instead, or replace the driver with WinUSB (Zadig).`;
    }
    return `Linux would not let Fold open this printer${at}. Add a udev rule for it, or add your user to the "lp"/"plugdev" group, then unplug and replug the printer.`;
  }
  if (/LIBUSB_ERROR_BUSY|resource busy/i.test(raw)) {
    return `This printer${at} is already in use by another program or by a printer queue. Close it there and try again.`;
  }
  if (/LIBUSB_ERROR_NO_DEVICE|no such device/i.test(raw)) {
    return `The printer${at} was unplugged while printing.`;
  }
  if (/LIBUSB_ERROR_TIMEOUT|timed out/i.test(raw)) {
    return `The printer${at} did not accept the data in time — check it is on, has paper, and its cover is closed.`;
  }
  return address ? `USB printer${at}: ${raw}` : raw;
}

function firstLine(e) {
  return String(e?.message || e || 'unknown error').split('\n')[0].trim();
}
