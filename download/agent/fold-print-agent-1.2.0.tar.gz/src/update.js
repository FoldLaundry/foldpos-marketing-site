// Updating the agent in place, with no admin rights and nobody watching.
//
// The counter computer runs whatever we installed on it, and until now that
// was the end of the story: a fix reached a shop only if its owner
// re-downloaded and reinstalled. So the heartbeat answers with an offer —
// `{ version, url, sha256 }` — and this applies it:
//
//   download to a temp file  →  verify the SHA-256  →  unpack beside it
//   →  rename into place     →  record it as wanted →  exit(RESTART)
//
// Everything about it is deliberately boring:
//
// * Nothing is overwritten. Versions land in their own directory under the
//   agent's data folder (`apps/1.2.0`), which the user owns, so no installer
//   and no elevation. The installed copy stays exactly as it was and remains
//   the fallback for ever.
// * The hash is checked before a single file is unpacked. A bundle that does
//   not match is deleted and the attempt recorded; we do not retry it.
// * The rename is the commit. A download that dies half way leaves a `.part`
//   directory and nothing else, and the next heartbeat tries again.
// * One attempt per version, and a quiet hour after a failure, so a bad
//   release cannot become a download loop on a shop's internet.
// * The caller only calls this between jobs, so an update never interrupts a
//   receipt that is printing.
//
// The supervisor in cli.js is what actually swaps over: it reads `wanted.json`
// at startup, runs that version, and falls back to the last good one if it
// will not start.
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';

import { appsDir, configDir, AGENT_VERSION } from './config.js';

const execFileP = promisify(execFile);

/** The child exits with this to tell the supervisor "run the new one". */
export const RESTART_EXIT_CODE = 75;

/** A failed version is not tried again for this long. */
export const RETRY_AFTER_MS = 60 * 60 * 1000;

/** A bundle larger than this is refused rather than filling a shop's disk. */
export const MAX_BUNDLE_BYTES = 40 * 1024 * 1024;

/**
 * A download gets this long and no more. The run loop awaits the update
 * between polls, so a bundle that trickles in — or a server that sends
 * headers and then goes quiet — would stop the shop printing for as long as
 * it took. Every other call this agent makes already has a deadline.
 */
export const DOWNLOAD_TIMEOUT_MS = 120_000;

/** What a tree must contain before anything will run it. */
export const REQUIRED_FILES = [
  'package.json',
  path.join('src', 'cli.js'),
  path.join('src', 'agent.js'),
  path.join('src', 'api.js'),
  path.join('src', 'config.js'),
  path.join('src', 'update.js'),
  path.join('src', 'supervisor.js'),
  path.join('src', 'status-server.js'),
  path.join('src', 'printers', 'index.js'),
];

export function statePath() {
  return path.join(configDir(), 'update-state.json');
}

/** Which version the supervisor should start, written beside the versions. */
export function wantedPath(dir = appsDir()) {
  return path.join(dir, 'wanted.json');
}

/**
 * The supervisor's strike file, read from here so a version it wrote off is
 * not downloaded all over again. Kept as a plain read to avoid importing the
 * supervisor into the updater (the supervisor imports this file).
 */
export function readBadVersions(dir = appsDir()) {
  try {
    return JSON.parse(fs.readFileSync(path.join(dir, 'bad-versions.json'), 'utf8'));
  } catch {
    return {};
  }
}

export function readState() {
  try {
    return JSON.parse(fs.readFileSync(statePath(), 'utf8'));
  } catch {
    return { attempts: {} };
  }
}

export function writeState(state) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(statePath(), JSON.stringify(state, null, 2));
  } catch {
    // Not being able to remember an attempt is not a reason to fail an update;
    // the worst case is one more try next hour.
  }
}

/**
 * Is this offer worth acting on? Pure, so every rule is a test.
 * @returns {{go: true} | {go: false, why: string}}
 */
export function shouldApply(offer, { current = AGENT_VERSION, state = { attempts: {} }, autoUpdate = true, now = Date.now(), installedVersions = [], badVersions = {} } = {}) {
  if (!autoUpdate) return { go: false, why: 'autoUpdate is off in config.json' };
  if (!offer || !offer.version) return { go: false, why: 'nothing offered' };
  if (!offer.url || !/^https:\/\//i.test(String(offer.url))) return { go: false, why: 'the offer has no https url' };
  if (!/^[a-f0-9]{64}$/i.test(String(offer.sha256 || ''))) return { go: false, why: 'the offer has no sha256' };
  if (compareVersions(offer.version, current) <= 0) return { go: false, why: `already running ${current}` };
  if (installedVersions.includes(offer.version)) return { go: false, why: `${offer.version} is already unpacked` };
  const attempt = state?.attempts?.[offer.version];
  if (attempt?.failedAt && now - attempt.failedAt < RETRY_AFTER_MS) {
    return { go: false, why: `${offer.version} failed ${Math.round((now - attempt.failedAt) / 60000)} min ago` };
  }
  if (attempt?.badHash) return { go: false, why: `${offer.version} did not match its hash` };
  // The supervisor already tried this one and it would not stay up.
  if ((badVersions?.[offer.version]?.strikes ?? 0) >= 2)
    return { go: false, why: `${offer.version} would not start on this computer` };
  return { go: true };
}

/** `1.10.0` beats `1.9.3`: numbers, not text. Same rule as the server's. */
export function compareVersions(a, b) {
  const parts = (v) =>
    String(v ?? '')
      .trim()
      .split(/[.+-]/)
      .map((n) => Number.parseInt(n, 10))
      .map((n) => (Number.isFinite(n) ? n : 0));
  const x = parts(a);
  const y = parts(b);
  for (let i = 0; i < Math.max(x.length, y.length); i += 1) {
    const d = (x[i] ?? 0) - (y[i] ?? 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

/** Which versions are already unpacked and look complete. */
export function installedVersions(dir = appsDir()) {
  try {
    return fs
      .readdirSync(dir, { withFileTypes: true })
      .filter((e) => e.isDirectory() && /^\d+\.\d+\.\d+/.test(e.name))
      .filter((e) =>
        REQUIRED_FILES.every((f) => fs.existsSync(path.join(dir, e.name, f))),
      )
      .map((e) => e.name)
      .sort(compareVersions);
  } catch {
    return [];
  }
}

/**
 * Download to a file. Refuses plain http, a redirect that leaves https, an
 * empty body and anything over [MAX_BUNDLE_BYTES].
 *
 * The deadline matters more than it looks: the run loop awaits the update
 * between polls, so a bundle that trickles in — or a server that sends
 * headers and then goes quiet — would stop the shop printing for as long as
 * it took, with a healthy-looking process the whole time. Same shape as every
 * other call the agent makes (api.js): a controller and a timer we clear,
 * not AbortSignal.timeout, whose timer is unref'd and holds nothing open.
 */
export async function download(
  url,
  dest,
  { fetchImpl = fetch, maxBytes = MAX_BUNDLE_BYTES, timeoutMs = DOWNLOAD_TIMEOUT_MS } = {},
) {
  if (!/^https:\/\//i.test(url)) throw new Error('refusing to download over plain http');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetchImpl(url, { redirect: 'manual', signal: ctrl.signal });
    if (res.status >= 300 && res.status < 400) {
      const to = res.headers?.get?.('location') ?? '';
      if (!/^https:\/\//i.test(to)) throw new Error('refusing to follow a redirect off https');
      return await download(to, dest, { fetchImpl, maxBytes, timeoutMs });
    }
    if (!res.ok) throw new Error(`download failed: HTTP ${res.status}`);
    const declared = Number(res.headers?.get?.('content-length') ?? 0);
    if (declared && declared > maxBytes)
      throw new Error(`bundle is ${declared} bytes, over the ${maxBytes} limit`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length > maxBytes)
      throw new Error(`bundle is ${buf.length} bytes, over the ${maxBytes} limit`);
    if (!buf.length) throw new Error('bundle is empty');
    await fsp.writeFile(dest, buf);
    return buf.length;
  } finally {
    clearTimeout(timer);
  }
}

export function sha256Of(file) {
  const hash = createHash('sha256');
  hash.update(fs.readFileSync(file));
  return hash.digest('hex');
}

/**
 * Unpack a .tar.gz with the tar that every supported OS already has — Windows
 * 10 1803 and later ship bsdtar as tar.exe, macOS and Linux have their own.
 * No dependency, and nothing of ours parses an archive a shop downloaded.
 */
export async function unpack(archive, intoDir, { exec = execFileP } = {}) {
  await fsp.mkdir(intoDir, { recursive: true });
  await exec('tar', ['-xzf', archive, '-C', intoDir], { timeout: 120_000, windowsHide: true });
  // Every file the agent needs to start, not just the entry point: a tree
  // with only cli.js in it reads as installed to everything downstream and
  // then fails to boot on the shop's counter.
  const missing = REQUIRED_FILES.filter((f) => !fs.existsSync(path.join(intoDir, f)));
  if (missing.length)
    throw new Error(`the bundle is missing ${missing.join(', ')} — not an agent bundle`);
}

/**
 * Apply an offer. Returns what happened, and never throws: a failed update
 * leaves the agent running exactly as it was, which is the whole point.
 *
 * @returns {Promise<{applied: boolean, version?: string, why?: string}>}
 */
export async function applyUpdate(offer, deps = {}) {
  const {
    log = () => {},
    dir = appsDir(),
    current = AGENT_VERSION,
    autoUpdate = true,
    now = () => Date.now(),
    fetchImpl = fetch,
    exec = execFileP,
    tmpDir = os.tmpdir(),
  } = deps;
  const state = deps.state ?? readState();
  const save = deps.writeState ?? writeState;

  const verdict = shouldApply(offer, {
    current,
    state,
    autoUpdate,
    now: now(),
    installedVersions: installedVersions(dir),
    badVersions: deps.badVersions ?? readBadVersions(dir),
  });
  if (!verdict.go) return { applied: false, why: verdict.why };

  const archive = path.join(tmpDir, `fold-print-agent-${offer.version}.tar.gz`);
  const part = path.join(dir, `${offer.version}.part`);
  const final = path.join(dir, offer.version);
  const fail = (why, extra = {}) => {
    state.attempts = state.attempts || {};
    state.attempts[offer.version] = { failedAt: now(), why, ...extra };
    save(state);
    log('warn', `update to ${offer.version} did not happen: ${why}`);
    return { applied: false, why };
  };

  // Recorded before a byte is fetched: a failure we never get to handle — the
  // power going off mid-download, the process killed — would otherwise leave
  // no trace and the agent would try again on the next poll, for ever.
  state.attempts = state.attempts || {};
  state.attempts[offer.version] = { startedAt: now(), failedAt: now(), why: 'started' };
  save(state);

  try {
    await fsp.mkdir(dir, { recursive: true });
    await fsp.rm(part, { recursive: true, force: true });
    log('info', `downloading agent ${offer.version}`);
    await download(offer.url, archive, { fetchImpl });
    const got = sha256Of(archive);
    if (got.toLowerCase() !== String(offer.sha256).toLowerCase()) {
      await fsp.rm(archive, { force: true });
      return fail('the download did not match its hash', { badHash: true });
    }
    await unpack(archive, part, { exec });
    await fsp.rm(archive, { force: true });
    // The rename is the commit. The old copy is moved aside first, never
    // deleted in place: a delete that half-finishes and a rename that then
    // fails would leave a tree that still has src/cli.js, which every check
    // here would read as a working version.
    const aside = `${final}.old-${now()}`;
    if (fs.existsSync(final)) await fsp.rename(final, aside).catch(() => {});
    await fsp.rename(part, final);
    await fsp.rm(aside, { recursive: true, force: true }).catch(() => {});
    await fsp.writeFile(
      wantedPath(dir),
      JSON.stringify({ version: offer.version, at: new Date(now()).toISOString(), from: current }, null, 2),
    );
    state.attempts = state.attempts || {};
    state.attempts[offer.version] = { appliedAt: now() };
    save(state);
    log('info', `agent ${offer.version} is unpacked; restarting into it`);
    return { applied: true, version: offer.version };
  } catch (e) {
    await fsp.rm(part, { recursive: true, force: true }).catch(() => {});
    await fsp.rm(archive, { force: true }).catch(() => {});
    return fail(e.message || String(e));
  }
}
