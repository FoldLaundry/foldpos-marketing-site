// Kept out of cli.js, which runs main() when imported.
import { ApiError } from './api.js';
import { AGENT_VERSION } from './config.js';

/**
 * The one-time code Fold POS put in the installer's file name:
 * "Fold-Print-Setup-k3m7x2p5q4ab.exe" — 12 base32 characters (60 bits), long
 * because nobody types it and it sits in a Downloads folder and a URL.
 * Browsers add " (1)" on a second download and Windows may keep a path in
 * front. Only the run directly after "Setup-" counts. Returns the code in
 * lower case, or null.
 */
export function pairingCodeFromInstallerName(fileName) {
  const base = String(fileName || '').split(/[\\/]/).pop();
  const m = base.match(/setup[-_ ]?([a-z2-7]{12})(?![a-z0-9])/i);
  return m ? m[1].toLowerCase() : null;
}

/** A code the pair endpoint accepts: 6 typed digits, or a 12-character download code. */
export function normalizePairingCode(code) {
  const raw = String(code || '').trim();
  if (/^[a-z2-7]{12}$/i.test(raw)) return raw.toLowerCase();
  const digits = raw.replace(/\D/g, '');
  return digits.length === 6 ? digits : null;
}

/**
 * `cli.js pair-from-installer <file name>`, run by the Windows installer
 * before the agent starts. Returns { code, message }; the installer reads the
 * exit code: 0 paired now, 3 already paired and still accepted (an upgrade
 * keeps its pairing), 4 nothing to pair with, 2 the code was refused.
 *
 * Uninstalling keeps config.json, so a computer revoked in Fold POS still
 * holds a token: it is checked with a heartbeat (no printer list, so the
 * server's copy is left alone) and replaced when the server says 401.
 */
export async function pairFromInstaller(cfg, fileName, { makeApi, pair, saveConfig, log = () => {} }) {
  const code = pairingCodeFromInstallerName(fileName);
  let current = cfg;
  if (current.token) {
    let revoked = false;
    try {
      await makeApi({ apiBase: current.apiBase, token: current.token }).heartbeat({ version: AGENT_VERSION });
    } catch (e) {
      revoked = e instanceof ApiError && e.status === 401;
    }
    if (!revoked) return { code: 3, message: 'already paired' };
    if (!code) return { code: 4, message: 'pairing was revoked and the installer name has no code' };
    current = { ...current, token: null, agentId: null, businessId: null };
    saveConfig(current);
    log('info', 'stored pairing was revoked by the server; pairing again from the installer name');
  }
  if (!code) return { code: 4, message: 'no pairing code in the installer name' };
  try {
    await pair(current, code);
    return { code: 0, message: 'paired' };
  } catch (e) {
    log('warn', `pairing from the installer name failed: ${e.message}`);
    return { code: 2, message: `pairing failed: ${e.message}` };
  }
}
